<?php
/*
Plugin Name: CM CV Plugin v1.1
Description: Adds backend placeholders for easier CV editing
Version: 1.1
Author: ConnorMoizer.com
*/

if (!defined('ABSPATH')) exit;

// CPT
add_action('init', function () {
    register_post_type('cm_cv', [
        'label'=>'CV',
        'public'=>true,
        'menu_icon'=>'dashicons-id',
        'supports'=>['title'],
        'rewrite'=>['slug'=>'cv','with_front'=>false],
    ]);
});

// META BOX WITH PLACEHOLDERS
add_action('add_meta_boxes', function () {
    add_meta_box('cm_cv_builder','CV Builder',function($post){

        $data=json_decode(get_post_meta($post->ID,'_cv',true),true);
        if(!$data)$data=['work'=>[],'education'=>[],'skills'=>[],'hobbies'=>''];

?>

<h3>Skills</h3>
<div id="skills-wrap">
<?php foreach($data['skills'] as $i=>$s){ ?>
<div class="item">
<input name="skills[<?php echo $i;?>][title]" placeholder="Skill (e.g. Microsoft Office)" value="<?php echo esc_attr($s['title']);?>">
<button type="button" onclick="this.parentNode.remove()">Delete</button>
</div>
<?php } ?>
</div>
<button type="button" onclick="addSkill()">+ Add Skill</button>

<h3>Work</h3>
<div id="work-wrap">
<?php foreach($data['work'] as $i=>$w){ ?>
<div class="item">
<input name="work[<?php echo $i;?>][title]" placeholder="Job Title" value="<?php echo esc_attr($w['title']);?>">
<input name="work[<?php echo $i;?>][location]" placeholder="Location (e.g. Leeds Arena)" value="<?php echo esc_attr($w['location']);?>">
<input name="work[<?php echo $i;?>][company]" placeholder="Company / Operational Management" value="<?php echo esc_attr($w['company']);?>">
<input name="work[<?php echo $i;?>][date]" placeholder="Date (e.g. Mar 2022 – Present)" value="<?php echo esc_attr($w['date']);?>">
<textarea name="work[<?php echo $i;?>][desc]" placeholder="Description"><?php echo esc_textarea($w['desc']);?></textarea>
<button type="button" onclick="this.parentNode.remove()">Delete</button>
</div>
<?php } ?>
</div>
<button type="button" onclick="addWork()">+ Add Work</button>

<h3>Education</h3>
<div id="edu-wrap">
<?php foreach($data['education'] as $i=>$e){ ?>
<div class="item">
<input name="education[<?php echo $i;?>][title]" placeholder="Course / Qualification" value="<?php echo esc_attr($e['title']);?>">
<input name="education[<?php echo $i;?>][location]" placeholder="Location (e.g. Leeds City College)" value="<?php echo esc_attr($e['location']);?>">
<input name="education[<?php echo $i;?>][group]" placeholder="Educational Group / Trust" value="<?php echo esc_attr($e['group']);?>">
<input name="education[<?php echo $i;?>][date]" placeholder="Date (e.g. 2015 – 2017)" value="<?php echo esc_attr($e['date']);?>">
<textarea name="education[<?php echo $i;?>][desc]" placeholder="Description"><?php echo esc_textarea($e['desc']);?></textarea>
<button type="button" onclick="this.parentNode.remove()">Delete</button>
</div>
<?php } ?>
</div>
<button type="button" onclick="addEdu()">+ Add Education</button>

<h3>Hobbies</h3>
<?php wp_editor($data['hobbies'],'hobbies_editor',['textarea_name'=>'hobbies']); ?>

<script>
function addSkill(){
let i=document.querySelectorAll('#skills-wrap .item').length;
document.getElementById('skills-wrap').insertAdjacentHTML('beforeend',`
<div class="item">
<input name="skills[${i}][title]" placeholder="Skill (e.g. Microsoft Office)">
<button onclick="this.parentNode.remove()">Delete</button>
</div>`);
}
function addWork(){
let i=document.querySelectorAll('#work-wrap .item').length;
document.getElementById('work-wrap').insertAdjacentHTML('beforeend',`
<div class="item">
<input name="work[${i}][title]" placeholder="Job Title">
<input name="work[${i}][location]" placeholder="Location">
<input name="work[${i}][company]" placeholder="Company / Operational Management">
<input name="work[${i}][date]" placeholder="Date">
<textarea name="work[${i}][desc]" placeholder="Description"></textarea>
<button onclick="this.parentNode.remove()">Delete</button>
</div>`);
}
function addEdu(){
let i=document.querySelectorAll('#edu-wrap .item').length;
document.getElementById('edu-wrap').insertAdjacentHTML('beforeend',`
<div class="item">
<input name="education[${i}][title]" placeholder="Course / Qualification">
<input name="education[${i}][location]" placeholder="Location">
<input name="education[${i}][group]" placeholder="Educational Group / Trust">
<input name="education[${i}][date]" placeholder="Date">
<textarea name="education[${i}][desc]" placeholder="Description"></textarea>
<button onclick="this.parentNode.remove()">Delete</button>
</div>`);
}
</script>

<style>.item{border:1px solid #ddd;padding:10px;margin:10px 0}input,textarea{width:100%;margin:5px 0}</style>

<?php
    },'cm_cv');
});

// SAVE
add_action('save_post_cm_cv', function($id){
$data=[
'work'=>array_values($_POST['work']??[]),
'education'=>array_values($_POST['education']??[]),
'skills'=>array_values($_POST['skills']??[]),
'hobbies'=>$_POST['hobbies']??''
];
update_post_meta($id,'_cv',json_encode($data));
});
