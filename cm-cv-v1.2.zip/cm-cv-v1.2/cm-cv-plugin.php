<?php
/*
Plugin Name: CM CV Plugin v1.2
Description: v1.1 + Elementor Widget restored
Version: 1.2
Author: ConnorMoizer.com
*/

if (!defined('ABSPATH')) exit;

// CPT
add_action('init', function () {
    register_post_type('cm_cv', [
        'label'=>'CV',
        'public'=>true,
        'menu_icon'=>'dashicons-id',
        'supports'=>['title'],
        'rewrite'=>['slug'=>'cv','with_front'=>false],
    ]);
});

// META BOX (same as v1.1 with placeholders)
add_action('add_meta_boxes', function () {
    add_meta_box('cm_cv_builder','CV Builder',function($post){

        $data=json_decode(get_post_meta($post->ID,'_cv',true),true);
        if(!$data)$data=['work'=>[],'education'=>[],'skills'=>[],'hobbies'=>''];
?>

<h3>Skills</h3>
<div id="skills-wrap">
<?php foreach($data['skills'] as $i=>$s){ ?>
<div class="item">
<input name="skills[<?php echo $i;?>][title]" placeholder="Skill (e.g. Microsoft Office)" value="<?php echo esc_attr($s['title']);?>">
<button type="button" onclick="this.parentNode.remove()">Delete</button>
</div>
<?php } ?>
</div>
<button type="button" onclick="addSkill()">+ Add Skill</button>

<h3>Work</h3>
<div id="work-wrap">
<?php foreach($data['work'] as $i=>$w){ ?>
<div class="item">
<input name="work[<?php echo $i;?>][title]" placeholder="Job Title" value="<?php echo esc_attr($w['title']);?>">
<input name="work[<?php echo $i;?>][location]" placeholder="Location (e.g. Leeds Arena)" value="<?php echo esc_attr($w['location']);?>">
<input name="work[<?php echo $i;?>][company]" placeholder="Company / Operational Management" value="<?php echo esc_attr($w['company']);?>">
<input name="work[<?php echo $i;?>][date]" placeholder="Date (e.g. Mar 2022 – Present)" value="<?php echo esc_attr($w['date']);?>">
<textarea name="work[<?php echo $i;?>][desc]" placeholder="Description"><?php echo esc_textarea($w['desc']);?></textarea>
<button type="button" onclick="this.parentNode.remove()">Delete</button>
</div>
<?php } ?>
</div>
<button type="button" onclick="addWork()">+ Add Work</button>

<h3>Education</h3>
<div id="edu-wrap">
<?php foreach($data['education'] as $i=>$e){ ?>
<div class="item">
<input name="education[<?php echo $i;?>][title]" placeholder="Course / Qualification" value="<?php echo esc_attr($e['title']);?>">
<input name="education[<?php echo $i;?>][location]" placeholder="Location (e.g. Leeds City College)" value="<?php echo esc_attr($e['location']);?>">
<input name="education[<?php echo $i;?>][group]" placeholder="Educational Group / Trust" value="<?php echo esc_attr($e['group']);?>">
<input name="education[<?php echo $i;?>][date]" placeholder="Date (e.g. 2015 – 2017)" value="<?php echo esc_attr($e['date']);?>">
<textarea name="education[<?php echo $i;?>][desc]" placeholder="Description"><?php echo esc_textarea($e['desc']);?></textarea>
<button type="button" onclick="this.parentNode.remove()">Delete</button>
</div>
<?php } ?>
</div>
<button type="button" onclick="addEdu()">+ Add Education</button>

<h3>Hobbies</h3>
<?php wp_editor($data['hobbies'],'hobbies_editor',['textarea_name'=>'hobbies']); ?>

<script>
function addSkill(){
let i=document.querySelectorAll('#skills-wrap .item').length;
document.getElementById('skills-wrap').insertAdjacentHTML('beforeend',`
<div class="item">
<input name="skills[${i}][title]" placeholder="Skill">
<button onclick="this.parentNode.remove()">Delete</button>
</div>`);
}
function addWork(){
let i=document.querySelectorAll('#work-wrap .item').length;
document.getElementById('work-wrap').insertAdjacentHTML('beforeend',`
<div class="item">
<input name="work[${i}][title]" placeholder="Job Title">
<input name="work[${i}][location]" placeholder="Location">
<input name="work[${i}][company]" placeholder="Company">
<input name="work[${i}][date]" placeholder="Date">
<textarea name="work[${i}][desc]" placeholder="Description"></textarea>
<button onclick="this.parentNode.remove()">Delete</button>
</div>`);
}
function addEdu(){
let i=document.querySelectorAll('#edu-wrap .item').length;
document.getElementById('edu-wrap').insertAdjacentHTML('beforeend',`
<div class="item">
<input name="education[${i}][title]" placeholder="Course">
<input name="education[${i}][location]" placeholder="Location">
<input name="education[${i}][group]" placeholder="Educational Group">
<input name="education[${i}][date]" placeholder="Date">
<textarea name="education[${i}][desc]" placeholder="Description"></textarea>
<button onclick="this.parentNode.remove()">Delete</button>
</div>`);
}
</script>

<style>.item{border:1px solid #ddd;padding:10px;margin:10px 0}input,textarea{width:100%;margin:5px 0}</style>

<?php
    },'cm_cv');
});

// SAVE
add_action('save_post_cm_cv', function($id){
$data=[
'work'=>array_values($_POST['work']??[]),
'education'=>array_values($_POST['education']??[]),
'skills'=>array_values($_POST['skills']??[]),
'hobbies'=>$_POST['hobbies']??''
];
update_post_meta($id,'_cv',json_encode($data));
});

// ELEMENTOR WIDGET (RESTORED)
add_action('elementor/widgets/register', function($widgets_manager){

if (!class_exists('\Elementor\Widget_Base')) return;

class CM_CV_Widget extends \Elementor\Widget_Base {

public function get_name(){ return 'cm_cv'; }
public function get_title(){ return 'CM CV'; }
public function get_icon(){ return 'eicon-person'; }
public function get_categories(){ return ['general']; }

protected function register_controls(){
$this->start_controls_section('content',['label'=>'Content']);

$this->add_control('sections',[
'type'=>\Elementor\Controls_Manager::SELECT2,
'multiple'=>true,
'options'=>[
'skills'=>'Skills',
'work'=>'Work',
'education'=>'Education',
'hobbies'=>'Hobbies'
],
'default'=>['skills','work','education','hobbies']
]);

$this->add_control('show_dividers',[
'type'=>\Elementor\Controls_Manager::SWITCHER,
'default'=>'yes'
]);

$this->end_controls_section();
}

protected function render(){

global $post;
$data=json_decode(get_post_meta($post->ID,'_cv',true),true);
if(!$data) return;

$sections=$this->get_settings_for_display('sections');
$show=$this->get_settings_for_display('show_dividers')==='yes';

echo '<div class="cm-cv">';

// SKILLS
if(in_array('skills',$sections)){
if($show) echo '<div class="cm-divider"><span>Skills</span></div>';
foreach($data['skills'] as $item){
echo '<div class="cm-card"><h3>'.$item['title'].'</h3></div>';
}
}

// WORK
if(in_array('work',$sections)){
if($show) echo '<div class="cm-divider"><span>Work</span></div>';
foreach($data['work'] as $item){
echo '<div class="cm-card">';
echo '<h3>'.$item['title'].' — '.$item['location'].'</h3>';
echo '<p><strong>Company:</strong> '.$item['company'].'</p>';
echo '<p><strong>Date:</strong> '.$item['date'].'</p>';
echo '<div>'.$item['desc'].'</div>';
echo '</div>';
}
}

// EDUCATION
if(in_array('education',$sections)){
if($show) echo '<div class="cm-divider"><span>Education</span></div>';
foreach($data['education'] as $item){
echo '<div class="cm-card">';
echo '<h3>'.$item['title'].' — '.$item['location'].'</h3>';
echo '<p><strong>Educational Group:</strong> '.$item['group'].'</p>';
echo '<p><strong>Date:</strong> '.$item['date'].'</p>';
echo '<div>'.$item['desc'].'</div>';
echo '</div>';
}
}

// HOBBIES
if(in_array('hobbies',$sections)){
if($show) echo '<div class="cm-divider"><span>Hobbies</span></div>';
echo '<div class="cm-card">'.$data['hobbies'].'</div>';
}

echo '</div>';
?>

<style>
.cm-divider{display:flex;align-items:center;justify-content:center;margin:30px 0;font-size:14px;color:#777;}
.cm-divider:before,.cm-divider:after{content:'';flex:1;height:1px;background:#ddd;}
.cm-divider span{padding:0 15px;}
.cm-card{background:#f5f5f7;padding:20px;border-radius:10px;margin-bottom:15px;}
.cm-cv h3,.cm-cv p,.cm-cv div{font-size:16px;}
.cm-cv h3{font-weight:700;}
</style>

<?php
}
}

$widgets_manager->register(new CM_CV_Widget());
});
