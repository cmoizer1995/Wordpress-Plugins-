<?php
/**
 * Plugin Name: CM Liveblog
 * Version: 1.0.0
 * Author: ConnorMoizer.com
 * Description: Live blog system with ACF repeater, real-time updates, and Elementor-compatible frontend.
 */

if (!defined('ABSPATH')) exit;

/* CPT */
add_action('init', function(){
    register_post_type('cm_liveblog', [
        'label'=>'Live Blogs',
        'public'=>true,
        'menu_icon'=>'dashicons-megaphone',
        'supports'=>['title','author']
    ]);
});

/* ACF */
add_action('acf/init', function(){
    if(!function_exists('acf_add_local_field_group')) return;

    acf_add_local_field_group([
        'key' => 'group_liveblog',
        'title' => 'Live Blog',
        'fields' => [

            [
                'key' => 'field_status',
                'label' => 'Status',
                'name' => 'status',
                'type' => 'select',
                'choices' => [
                    'live' => 'Live',
                    'soon' => 'Coming Soon'
                ],
                'default_value' => 'soon'
            ],

            [
                'key' => 'field_updates',
                'label' => 'Updates',
                'name' => 'live_updates',
                'type' => 'repeater',
                'layout' => 'block',
                'button_label' => 'Add Update',
                'sub_fields' => [

                    ['key'=>'field_user','label'=>'User','name'=>'user','type'=>'text'],
                    ['key'=>'field_title','label'=>'Event','name'=>'title','type'=>'text'],
                    ['key'=>'field_time','label'=>'Time','name'=>'time','type'=>'text'],
                    ['key'=>'field_content','label'=>'Details','name'=>'content','type'=>'wysiwyg']

                ]
            ]
        ],
        'location' => [[[ 'param'=>'post_type','operator'=>'==','value'=>'cm_liveblog' ]]],
    ]);
});

/* Timestamp */
add_action('acf/save_post', function($post_id){
    if(get_post_type($post_id) !== 'cm_liveblog') return;
    if(!function_exists('get_field')) return;

    $rows = get_field('live_updates', $post_id);
    if(!$rows || !is_array($rows)) return;

    foreach($rows as $i => $row){
        if(empty($row['time'])){
            $rows[$i]['time'] = current_time('H:i');
        }
    }

    update_field('live_updates', $rows, $post_id);

}, 20);

/* Frontend */
add_filter('the_content', function($content){

    if(is_singular('cm_liveblog') && in_the_loop() && is_main_query()){

        if(!function_exists('get_field')){
            return '<p>ACF required</p>';
        }

        $rows = get_field('live_updates');
        $status = get_field('status');

        $status_attr = $status ? $status : 'soon';
        $count = is_array($rows) ? count($rows) : 0;

        ob_start();

        echo '<div class="cm-liveblog" data-status="'.$status_attr.'" data-count="'.$count.'">';

        if($status === 'live'){
            echo '<div class="cm-live-indicator">LIVE</div>';
        }

        if(!empty($rows)){
            $rev = array_reverse($rows);
            $i=0;

            foreach($rev as $row){

                $time = esc_html($row['time']);
                $user = !empty($row['user']) ? esc_html($row['user']) : get_the_author();
                $title = esc_html($row['title']);
                $content = wp_kses_post($row['content']);

                $is_new = ($i===0) ? 'cm-new' : '';

                echo '<div class="cm-card '.$is_new.'">';
                echo '<div class="cm-title">'.$title.'</div>';
                echo '<div class="cm-meta">'.$time.' • <strong>'.$user.'</strong></div>';
                echo '<div class="cm-body">'.$content.'</div>';
                echo '</div>';

                $i++;
            }
        }

        echo '</div>';
        ?>

        <div id="cm-live-notice" class="cm-live-notice" style="display:none;">
            New update available <button onclick="location.reload()">Refresh</button>
        </div>

        <script>
        document.addEventListener("DOMContentLoaded",function(){

            const wrap=document.querySelector(".cm-liveblog");
            if(!wrap) return;

            if(wrap.dataset.status!=="live") return;

            let count=parseInt(wrap.dataset.count || 0);

            setInterval(()=>{
                try{
                    fetch(location.href)
                    .then(r=>r.text())
                    .then(t=>{
                        let m=t.match(/data-count="(\d+)"/);
                        if(m && parseInt(m[1])>count){
                            document.getElementById("cm-live-notice").style.display="block";
                        }
                    });
                }catch(e){}
            },15000);

            setInterval(()=>location.reload(),60000);

        });
        </script>

        <?php

        return ob_get_clean();
    }

    return $content;
});

/* Admin */
add_action('admin_enqueue_scripts', function($hook){
    global $post;
    if(($hook==='post.php'||$hook==='post-new.php') && isset($post) && $post->post_type==='cm_liveblog'){
        wp_enqueue_script('cm-admin', plugin_dir_url(__FILE__).'admin.js',['jquery'],false,true);
    }
});

/* Styles */
add_action('wp_enqueue_scripts', function(){
    wp_enqueue_style('cm-style', plugin_dir_url(__FILE__).'style.css');
});
