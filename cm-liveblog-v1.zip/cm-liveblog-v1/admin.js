jQuery(function($){

    const addBtn = $('.acf-actions .acf-button');

    if(addBtn.length && !$('.cm-save').length){
        const saveBtn = $('<a class="acf-button button button-primary cm-save">Save Updates</a>');
        saveBtn.css({marginLeft:'20px'});

        saveBtn.on('click', function(e){
            e.preventDefault();
            $('form#post').submit();
        });

        addBtn.after(saveBtn);
    }

    function addDelete(){
        $('.acf-row').each(function(){

            if($(this).find('.cm-del').length) return;

            const btn = $('<a class="button cm-del" style="margin-top:10px;background:#dc3545;color:#fff;">Delete Update</a>');

            btn.on('click', function(e){
                e.preventDefault();
                e.stopPropagation();

                const row = $(this).closest('.acf-row');
                const minusBtn = row.find('.acf-icon.-minus');

                if(minusBtn.length){
                    minusBtn.trigger('click');
                }

                setTimeout(function(){
                    $('form#post').submit();
                }, 500);

            });

            $(this).append(btn);
        });
    }

    addDelete();

    $(document).on('click', '.acf-button', function(){
        setTimeout(addDelete, 200);
    });

});
