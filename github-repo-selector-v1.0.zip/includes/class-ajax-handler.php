<?php
/**
 * AJAX Handlers
 */

namespace GitHub_Repo_Selector;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AJAX_Handler {
	public static function init() {
		add_action( 'wp_ajax_fetch_github_repos', [ __CLASS__, 'fetch_github_repos' ] );
		add_action( 'wp_ajax_fetch_github_repo_readme', [ __CLASS__, 'fetch_github_repo_readme' ] );
		add_action( 'wp_ajax_nopriv_fetch_github_repo_readme', [ __CLASS__, 'fetch_github_repo_readme' ] );
	}

	public static function fetch_github_repos() {
		// Security check
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				[
					'message' => __( 'Insufficient permissions', 'github-repo-selector' ),
				],
				403
			);
		}

		// Verify nonce
		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( $_POST['nonce'] ) : '';
		if ( ! empty( $nonce ) && ! wp_verify_nonce( $nonce, 'github_repo_selector_nonce' ) ) {
			wp_send_json_error(
				[
					'message' => __( 'Security check failed', 'github-repo-selector' ),
				],
				403
			);
		}

		// Fetch repositories for the GitHub account connected to the saved token.
		$api = new GitHub_API();
		$username = $api->get_authenticated_username();

		if ( empty( $username ) ) {
			wp_send_json_error(
				[
					'message' => __( 'No GitHub account found from the saved token. Add a valid token in Settings > GitHub Repo Selector.', 'github-repo-selector' ),
				]
			);
		}

		$api->clear_cache( '', '', false );
		$repos = $api->get_user_repos( $username, true );

		if ( empty( $repos ) || ! is_array( $repos ) ) {
			wp_send_json_error(
				[
					'message' => __( 'No repositories found or error fetching repositories', 'github-repo-selector' ),
				]
			);
		}

		// Save repo names so Elementor dropdown/search has real options next time the widget panel opens.
		$repo_options = Settings::save_repo_options_from_repos( $repos );

		// Format response
		$formatted_repos = [];
		foreach ( $repos as $repo ) {
			$formatted_repos[] = [
				'name' => $repo['name'],
				'description' => $repo['description'] ?? '',
				'url' => $repo['html_url'],
				'stars' => $repo['stargazers_count'],
				'language' => $repo['language'] ?? 'Unknown',
			];
		}

		wp_send_json_success(
			[
				'repos' => $formatted_repos,
				'count' => count( $formatted_repos ),
				'username' => $username,
				'options'  => $repo_options,
			]
		);
	}

	public static function fetch_github_repo_readme() {
		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( $_POST['nonce'] ) : '';
		if ( ! empty( $nonce ) && ! wp_verify_nonce( $nonce, 'github_repo_selector_nonce' ) ) {
			wp_send_json_error( [ 'message' => __( 'Security check failed', 'github-repo-selector' ) ], 403 );
		}

		$owner  = isset( $_POST['owner'] ) ? sanitize_text_field( wp_unslash( $_POST['owner'] ) ) : '';
		$repo   = isset( $_POST['repo'] ) ? sanitize_text_field( wp_unslash( $_POST['repo'] ) ) : '';
		$branch = isset( $_POST['branch'] ) ? sanitize_text_field( wp_unslash( $_POST['branch'] ) ) : '';

		if ( empty( $owner ) || empty( $repo ) || empty( $branch ) ) {
			wp_send_json_error( [ 'message' => __( 'Missing repository or branch.', 'github-repo-selector' ) ] );
		}

		$api = new GitHub_API();
		$readme = $api->get_repo_readme( $owner, $repo, $branch );

		if ( '' === $readme ) {
			wp_send_json_error( [ 'message' => __( 'No README available for this branch.', 'github-repo-selector' ) ] );
		}

		wp_send_json_success( [ 'readme' => wp_kses_post( self::markdown_to_html( $readme ) ) ] );
	}

	private static function markdown_to_html( $markdown ) {
		$markdown = preg_replace( '/^### (.*?)$/m', '<h3>$1</h3>', $markdown );
		$markdown = preg_replace( '/^## (.*?)$/m', '<h2>$1</h2>', $markdown );
		$markdown = preg_replace( '/^# (.*?)$/m', '<h1>$1</h1>', $markdown );
		$markdown = preg_replace( '/\*\*(.*?)\*\*/', '<strong>$1</strong>', $markdown );
		$markdown = preg_replace( '/__(.+?)__/', '<strong>$1</strong>', $markdown );
		$markdown = preg_replace( '/`([^`]+)`/', '<code>$1</code>', $markdown );
		$markdown = preg_replace( '/\[(.*?)\]\((.*?)\)/', '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>', $markdown );
		return nl2br( $markdown );
	}
}

// Initialize AJAX handlers
AJAX_Handler::init();
