<?php
/**
 * Settings Handler
 */

namespace GitHub_Repo_Selector;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Settings {
	public static function get_github_token() {
		return get_option( 'github_repo_selector_token', '' );
	}

	public static function has_github_token() {
		return ! empty( self::get_github_token() );
	}

	public static function get_settings_url() {
		return admin_url( 'options-general.php?page=github-repo-selector' );
	}

	public static function get_saved_repo_options() {
		$options = get_option( 'github_repo_selector_repo_options', [] );
		return is_array( $options ) ? $options : [];
	}

	public static function save_repo_options_from_repos( $repos ) {
		$options = [];

		if ( is_array( $repos ) ) {
			foreach ( $repos as $repo ) {
				if ( empty( $repo['name'] ) ) {
					continue;
				}

				$options[ $repo['name'] ] = $repo['name'];
			}
		}

		update_option( 'github_repo_selector_repo_options', $options, false );
		update_option( 'github_repo_selector_repo_cache_updated', current_time( 'mysql' ), false );
		return $options;
	}
}
