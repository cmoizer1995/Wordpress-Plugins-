<?php
/**
 * GitHub API Handler
 */

namespace GitHub_Repo_Selector;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GitHub_API {
	private $token = '';
	private $base_url = 'https://api.github.com';
	private $cache_duration = 3600; // 1 hour

	public function __construct() {
		$this->token = get_option( 'github_repo_selector_token', '' );
	}

	/**
	 * Get the GitHub account connected to the saved token.
	 */
	public function get_authenticated_user() {
		$cache_key = 'github_authenticated_user';
		$cached = get_transient( $cache_key );

		if ( $cached ) {
			if ( ! empty( $cached['login'] ) ) {
				update_option( 'github_repo_selector_connected_username', sanitize_text_field( $cached['login'] ), false );
			}
			return $cached;
		}

		if ( empty( $this->token ) ) {
			return [];
		}

		$response = $this->make_request( $this->base_url . '/user' );

		if ( is_wp_error( $response ) || empty( $response['login'] ) ) {
			return [];
		}

		update_option( 'github_repo_selector_connected_username', sanitize_text_field( $response['login'] ), false );
		set_transient( $cache_key, $response, $this->cache_duration );

		return $response;
	}

	/**
	 * Get the GitHub username/login connected to the saved token.
	 */
	public function get_authenticated_username() {
		$user = $this->get_authenticated_user();
		return ! empty( $user['login'] ) ? $user['login'] : '';
	}

	/**
	 * Get user repositories
	 */
	public function get_user_repos( $username = '', $force_refresh = false ) {
		$authenticated_username = $this->get_authenticated_username();
		$username = ! empty( $username ) ? sanitize_text_field( $username ) : $authenticated_username;

		if ( empty( $username ) ) {
			return [];
		}

		$cache_key = 'github_repos_' . $username;
		$cached = get_transient( $cache_key );

		if ( $cached && ! $force_refresh ) {
			return $cached;
		}

		if ( ! empty( $authenticated_username ) && strtolower( $username ) === strtolower( $authenticated_username ) ) {
			$url = $this->base_url . '/user/repos?per_page=100&sort=updated&affiliation=owner,collaborator,organization_member';
		} else {
			$url = $this->base_url . '/users/' . rawurlencode( $username ) . '/repos?per_page=100&sort=updated';
		}

		$response = $this->make_paginated_request( $url );

		if ( is_wp_error( $response ) ) {
			return [];
		}

		set_transient( $cache_key, $response, $this->cache_duration );

		return $response;
	}

	/**
	 * Get repository branches
	 */
	public function get_repo_branches( $owner, $repo, $force_refresh = false ) {
		$cache_key = 'github_branches_' . $owner . '_' . $repo;
		$cached = get_transient( $cache_key );

		if ( $cached && ! $force_refresh ) {
			return $cached;
		}

		$url = $this->base_url . '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/branches?per_page=100';
		$response = $this->make_request( $url );

		if ( is_wp_error( $response ) ) {
			return [];
		}

		set_transient( $cache_key, $response, $this->cache_duration );

		return $response;
	}

	/**
	 * Get repository details
	 */
	public function get_repo_details( $owner, $repo, $force_refresh = false ) {
		$cache_key = 'github_repo_details_' . $owner . '_' . $repo;
		$cached = get_transient( $cache_key );

		if ( $cached && ! $force_refresh ) {
			return $cached;
		}

		$url = $this->base_url . '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo );
		$response = $this->make_request( $url );

		if ( is_wp_error( $response ) ) {
			return [];
		}

		set_transient( $cache_key, $response, $this->cache_duration );

		return $response;
	}

	/**
	 * Get repository README
	 */
	public function get_repo_readme( $owner, $repo, $branch = 'main', $force_refresh = false ) {
		$cache_key = 'github_readme_' . $owner . '_' . $repo . '_' . $branch;
		$cached = get_transient( $cache_key );

		if ( $cached && ! $force_refresh ) {
			return $cached;
		}

		$url = $this->base_url . '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/contents/README.md?ref=' . rawurlencode( $branch );
		
		$args = [
			'headers' => [
				'Accept' => 'application/vnd.github.v3.raw',
			],
		];

		if ( ! empty( $this->token ) ) {
			$args['headers']['Authorization'] = 'token ' . $this->token;
		}

		$response = wp_remote_get( $url, $args );

		if ( is_wp_error( $response ) ) {
			return '';
		}

		$status_code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== (int) $status_code ) {
			return '';
		}

		$body = wp_remote_retrieve_body( $response );
		set_transient( $cache_key, $body, $this->cache_duration );

		return $body;
	}

	/**
	 * Make API request
	 */
	private function make_request( $url ) {
		$args = [
			'headers' => [
				'Accept' => 'application/vnd.github.v3+json',
			],
		];

		if ( ! empty( $this->token ) ) {
			$args['headers']['Authorization'] = 'token ' . $this->token;
		}

		$response = wp_remote_get( $url, $args );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$status_code = wp_remote_retrieve_response_code( $response );

		if ( $status_code !== 200 ) {
			return new \WP_Error( 'github_api_error', 'GitHub API Error: ' . $status_code );
		}

		$body = wp_remote_retrieve_body( $response );
		return json_decode( $body, true );
	}


	/**
	 * Make paginated API requests and merge array results.
	 */
	private function make_paginated_request( $url ) {
		$all = [];
		$page = 1;

		while ( $page <= 10 ) {
			$separator = strpos( $url, '?' ) === false ? '?' : '&';
			$page_url = $url . $separator . 'page=' . $page;
			$response = $this->make_request( $page_url );

			if ( is_wp_error( $response ) ) {
				return $response;
			}

			if ( empty( $response ) || ! is_array( $response ) ) {
				break;
			}

			$all = array_merge( $all, $response );

			if ( count( $response ) < 100 ) {
				break;
			}

			$page++;
		}

		return $all;
	}

	/**
	 * Clear cache
	 */
	public function clear_cache( $owner = '', $repo = '', $delete_saved_options = true ) {
		if ( ! empty( $owner ) && ! empty( $repo ) ) {
			delete_transient( 'github_branches_' . $owner . '_' . $repo );
			delete_transient( 'github_repo_details_' . $owner . '_' . $repo );
			delete_transient( 'github_readme_' . $owner . '_' . $repo . '_main' );
			delete_transient( 'github_readme_' . $owner . '_' . $repo . '_master' );
		} else {
			$old_username = $this->get_authenticated_username();
			delete_transient( 'github_authenticated_user' );
			if ( ! empty( $old_username ) ) {
				delete_transient( 'github_repos_' . $old_username );
			}
			if ( $delete_saved_options ) {
				delete_option( 'github_repo_selector_repo_options' );
			}
		}
	}
}
