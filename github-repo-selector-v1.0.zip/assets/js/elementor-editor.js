( function( $ ) {
	'use strict';

	function getAjaxUrl() {
		if ( window.githubRepoSelectorEditor && window.githubRepoSelectorEditor.ajaxurl ) {
			return window.githubRepoSelectorEditor.ajaxurl;
		}
		if ( window.ajaxurl ) {
			return window.ajaxurl;
		}
		return '/wp-admin/admin-ajax.php';
	}

	function getNonce() {
		if ( window.githubRepoSelectorEditor && window.githubRepoSelectorEditor.nonce ) {
			return window.githubRepoSelectorEditor.nonce;
		}
		return window.githubRepoSelectorNonce || '';
	}

	function getControlsPanel() {
		return document.querySelector( '#elementor-panel' ) || document;
	}

	function handleRepoFetching() {
		const panel = getControlsPanel();

		if ( panel.dataset.githubRepoSelectorBound === 'yes' ) {
			return;
		}

		panel.dataset.githubRepoSelectorBound = 'yes';

		panel.addEventListener( 'click', function( e ) {
			const button = e.target.closest( '#update-github-repos' );

			if ( ! button ) {
				return;
			}

			e.preventDefault();

			button.disabled = true;
			button.textContent = 'Loading your GitHub repos...';

			fetch( getAjaxUrl(), {
				method: 'POST',
				credentials: 'same-origin',
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
				},
				body: new URLSearchParams( {
					action: 'fetch_github_repos',
					nonce: getNonce(),
				} ),
			} )
			.then( ( response ) => response.json() )
			.then( ( data ) => {
				if ( data.success ) {
					updateRepoDropdowns( data.data.repos );
					showMessage( 'Loaded ' + data.data.count + ' repositories from @' + data.data.username + '. Cache updated successfully.', 'success' );
					refreshAfterCacheUpdate( button, data.data );
				} else {
					showMessage( 'Error: ' + ( data.data && data.data.message ? data.data.message : 'Unable to fetch repositories' ), 'error' );
				}
			} )
			.catch( ( error ) => {
				console.error( 'Error:', error );
				showMessage( 'Error fetching repositories: ' + error.message, 'error' );
			} )
			.finally( () => {
				button.disabled = false;
				button.textContent = 'Update Repositories';
			} );
		} );
	}

	function updateRepoDropdowns( repos ) {
		const selectors = document.querySelectorAll(
			'select[data-setting="selected_repo_single"], select[data-setting="repo_name"], select[data-setting="selected_repos"]'
		);

		if ( ! selectors.length ) {
			showMessage( 'Repositories saved, but no open repository dropdown was found. Re-open the widget panel and the dropdown will be filled.', 'success' );
			return;
		}

		selectors.forEach( ( selectElement ) => {
			const $select = $( selectElement );
			const isMultiple = selectElement.hasAttribute( 'multiple' );
			const currentValues = $select.val() || ( isMultiple ? [] : '' );

			selectElement.innerHTML = '';

			if ( ! isMultiple ) {
				const placeholder = document.createElement( 'option' );
				placeholder.value = '';
				placeholder.textContent = 'Select a repository';
				selectElement.appendChild( placeholder );
			}

			repos.forEach( ( repo ) => {
				if ( ! repo.name ) {
					return;
				}

				const option = document.createElement( 'option' );
				option.value = repo.name;
				option.textContent = repo.name;
				selectElement.appendChild( option );
			} );

			if ( isMultiple ) {
				const valid = Array.isArray( currentValues ) ? currentValues.filter( ( value ) => repos.some( ( repo ) => repo.name === value ) ) : [];
				$select.val( valid );
			} else if ( repos.some( ( repo ) => repo.name === currentValues ) ) {
				$select.val( currentValues );
			} else {
				$select.val( '' );
			}

			$select.trigger( 'change' );
			$select.trigger( 'input' );
		} );
	}


	function refreshAfterCacheUpdate( button, payload ) {
		const isSettingsPage = button && button.getAttribute( 'data-refresh-settings' ) === 'yes';

		if ( isSettingsPage ) {
			const status = document.getElementById( 'github-repo-selector-cache-status' );
			if ( status && payload ) {
				status.innerHTML = '<strong>Cached repositories:</strong> ' + escapeHtml( String( payload.count || 0 ) ) + '<br><strong>Last updated:</strong> just now';
			}

			button.textContent = 'Updated — refreshing page...';
			setTimeout( function() {
				window.location.href = window.location.href.split( '#' )[0] + ( window.location.href.indexOf( '?' ) === -1 ? '?' : '&' ) + 'grs_cache_updated=' + Date.now();
			}, 900 );
			return;
		}

		// Elementor editor: force the panel/model to notice the changed select values.
		setTimeout( function() {
			if ( window.elementor && elementor.channels && elementor.channels.editor ) {
				elementor.channels.editor.trigger( 'change' );
			}
			initElementorSelect2Fixes();
		}, 250 );
	}

	function initElementorSelect2Fixes() {
		const panel = getControlsPanel();
		const selects = panel.querySelectorAll( 'select[data-setting="selected_repo_single"], select[data-setting="repo_name"], select[data-setting="selected_repos"]' );
		selects.forEach( function( selectElement ) {
			selectElement.style.width = '100%';
			const wrapper = selectElement.closest( '.elementor-control-input-wrapper, .elementor-control-field, .elementor-repeater-row-controls' );
			if ( wrapper ) {
				wrapper.style.overflow = 'visible';
			}

			const select2 = selectElement.parentNode ? selectElement.parentNode.querySelector( '.select2-container' ) : null;
			if ( select2 ) {
				select2.style.width = '100%';
				select2.style.maxWidth = '100%';
			}
		} );
	}


	let githubRepoSelectorPreviewTimer = null;
	function forceElementorPreviewRefresh() {
		clearTimeout( githubRepoSelectorPreviewTimer );
		githubRepoSelectorPreviewTimer = setTimeout( function() {
			if ( window.elementor && typeof elementor.reloadPreview === 'function' ) {
				elementor.reloadPreview();
				return;
			}
			if ( window.elementor && elementor.channels && elementor.channels.editor ) {
				elementor.channels.editor.trigger( 'change' );
			}
		}, 350 );
	}

	function bindLivePreviewRefresh() {
		const panel = getControlsPanel();
		if ( panel.dataset.githubRepoSelectorPreviewBound === 'yes' ) {
			return;
		}
		panel.dataset.githubRepoSelectorPreviewBound = 'yes';
		panel.addEventListener( 'change', function( e ) {
			const target = e.target;
			if ( ! target || ! target.matches ) {
				return;
			}
			if ( target.matches( 'select[data-setting="repo_selection_mode"], select[data-setting="selected_repo_single"], select[data-setting="repo_name"], input[data-setting="default_branch"]' ) ) {
				forceElementorPreviewRefresh();
			}
		} );
	}

	function showMessage( message, type ) {
		const existingMessage = document.querySelector( '.github-repos-message' );
		if ( existingMessage ) {
			existingMessage.remove();
		}

		const settingsMessage = document.getElementById( 'github-repo-selector-settings-cache-message' );
		if ( settingsMessage ) {
			settingsMessage.className = 'notice ' + ( type === 'success' ? 'notice-success' : 'notice-error' ) + ' github-repos-message github-repos-' + type;
			settingsMessage.innerHTML = '<p>' + escapeHtml( message ) + '</p>';
			settingsMessage.style.display = 'block';
			return;
		}

		const button = document.getElementById( 'update-github-repos' );
		if ( ! button ) {
			return;
		}

		const messageDiv = document.createElement( 'div' );
		messageDiv.className = 'github-repos-message github-repos-' + type;
		messageDiv.textContent = message;
		messageDiv.style.marginTop = '10px';
		messageDiv.style.padding = '8px';
		messageDiv.style.borderRadius = '4px';
		messageDiv.style.background = type === 'success' ? '#edfaef' : '#fff1f0';
		messageDiv.style.border = type === 'success' ? '1px solid #2da44e' : '1px solid #cf222e';

		button.parentNode.insertBefore( messageDiv, button.nextSibling );
	}

	function escapeHtml( text ) {
		const div = document.createElement( 'div' );
		div.textContent = text;
		return div.innerHTML;
	}

	if ( window.elementor ) {
		elementor.on( 'preview:loaded', handleRepoFetching );
		elementor.channels.editor.on( 'section:activated', handleRepoFetching );
	}

	$( document ).ready( function() { handleRepoFetching(); initElementorSelect2Fixes(); bindLivePreviewRefresh(); } );

	const observer = new MutationObserver( function() { initElementorSelect2Fixes(); bindLivePreviewRefresh(); } );
	observer.observe( document.body, { childList: true, subtree: true } );
} )( jQuery );
