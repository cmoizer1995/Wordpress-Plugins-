# GitHub Repo Selector for Elementor

Version v1.0

## What changed in this build

- Elementor now has a repo display mode:
  - **Add one repo**
  - **Add multiple repos as a list**
- Repository controls now use searchable dropdowns populated from the GitHub account connected to the saved token.
- The **Update Repositories** button fetches repos from the connected token account and saves them for the dropdown/search controls.
- Branch selection no longer falls back to `main` after you choose another branch.
- Repository title links and the **View on GitHub** button now point to the selected branch URL.
- README content now loads from the selected branch.
- Initial branch display uses the repository’s actual GitHub default branch instead of assuming `main`.

## Setup

1. Install and activate the plugin ZIP.
2. Go to **Settings → GitHub Repo Selector**.
3. Save your GitHub token.
4. Open the Elementor widget.
5. Click **Update Repositories**.
6. Choose **Add one repo** or **Add multiple repos as a list**.
7. Use the searchable dropdown to select your repos.

If the dropdown is empty immediately after pressing update, close and reopen the Elementor widget panel. The fetched repo list is saved in WordPress options.


## v1.0
- Restored v1.0-style repository dropdown controls for both single repo and multiple repo repeater rows.
- Kept the settings cache update fix and repo count/notification behaviour.
