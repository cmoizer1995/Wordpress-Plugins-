<?php
/**
 * GitHub Repo Selector Elementor Widget
 */

namespace GitHub_Repo_Selector\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use GitHub_Repo_Selector\GitHub_API;
use GitHub_Repo_Selector\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GitHub_Repo_Widget extends Widget_Base {
	private $github_api;

	public function __construct( $data = [], $args = null ) {
		parent::__construct( $data, $args );
		$this->github_api = new GitHub_API();
	}

	public function get_name() {
		return 'github_repo_selector';
	}

	public function get_title() {
		return esc_html__( 'GitHub Repos', 'github-repo-selector' );
	}

	public function get_icon() {
		return 'eicon-code';
	}

	public function get_categories() {
		return [ 'general' ];
	}

	public function get_keywords() {
		return [ 'github', 'repository', 'repos', 'code' ];
	}

	protected function register_controls() {
		// GitHub Settings Section
		$this->start_controls_section(
			'section_github_settings',
			[
				'label' => esc_html__( 'GitHub Settings', 'github-repo-selector' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$settings_url = Settings::get_settings_url();

		$this->add_control(
			'github_token_account_notice',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => '<div style="background: #f0f6fc; border-left: 4px solid #0969da; padding: 12px; margin: 12px 0; border-radius: 4px; color: #24292f; font-size: 12px;">' .
					'<strong>GitHub account:</strong> This widget now uses the account connected to your saved GitHub token. ' .
					'<a href="' . esc_url( $settings_url ) . '" target="_blank" rel="noopener noreferrer">Open GitHub Repo Selector settings</a> to change the token.' .
				'</div>',
			]
		);

		$this->add_control(
			'fetch_repos_notice',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => '<div style="background: #f0f6fc; border-left: 4px solid #0969da; padding: 12px; margin: 12px 0; border-radius: 4px; color: #24292f; font-size: 12px;">
					<strong>Info:</strong> Click "Update Repositories" to fetch repositories from the GitHub account connected to the saved token.
				</div>',
			]
		);

		$this->add_control(
			'update_repos_button',
			[
				'type'  => Controls_Manager::RAW_HTML,
				'raw'   => '<button type="button" id="update-github-repos" class="elementor-button elementor-button-default github-repo-selector-update" style="margin: 10px 0;">Update Repositories</button><div class="github-repo-selector-mobile-note" style="font-size:11px;opacity:.8;margin-top:6px;">Updates the saved repo cache, then refreshes the Elementor controls.</div>',
				'label' => '',
			]
		);

		$repo_options = Settings::get_saved_repo_options();

		$this->add_control(
			'repo_cache_status',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => '<div style="font-size:12px; padding:8px 10px; background:#f6f7f7; border:1px solid #dcdcde; border-radius:4px; margin-bottom:10px;"><strong>Repo cache:</strong> ' . esc_html( count( $repo_options ) ) . ' repositories loaded.</div>',
			]
		);

		$this->add_control(
			'repo_selection_mode',
			[
				'label'       => esc_html__( 'Repo Display Mode', 'github-repo-selector' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'multiple',
				'options'     => [
					'all'      => esc_html__( 'Add all repositories', 'github-repo-selector' ),
					'single'   => esc_html__( 'Add one repo', 'github-repo-selector' ),
					'multiple' => esc_html__( 'Add multiple repos as a list', 'github-repo-selector' ),
				],
				'description' => esc_html__( 'Choose all repositories at once, one repository, or build a custom list of repositories.', 'github-repo-selector' ),
				'render_type' => 'template',
				'frontend_available' => true,
			]
		);



		$this->add_control(
			'all_repos_notice',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => '<div style="font-size:12px; padding:8px 10px; background:#f6f7f7; border:1px solid #dcdcde; border-radius:4px; margin-bottom:10px;"><strong>All repositories:</strong> This will render every repository currently saved in the repo cache. Use Update Repositories in settings/editor to refresh the list.</div>',
				'condition' => [
					'repo_selection_mode' => 'all',
				],
			]
		);

		$this->add_control(
			'selected_repo_single',
			[
				'label'       => esc_html__( 'Repository', 'github-repo-selector' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => '',
				'options'     => array_merge( [ '' => esc_html__( 'Select a repository', 'github-repo-selector' ) ], $repo_options ),
				'label_block' => true,
				'description' => empty( $repo_options ) ? esc_html__( 'Click Update Repositories first. The dropdown will fill with repos from your saved GitHub token.', 'github-repo-selector' ) : esc_html__( 'Select one repository from the dropdown connected to your GitHub token.', 'github-repo-selector' ),
				'condition'   => [
					'repo_selection_mode' => 'single',
				],
				'render_type' => 'template',
				'frontend_available' => true,
			]
		);

		$repo_repeater = new Repeater();
		$repo_repeater->add_control(
			'repo_name',
			[
				'label'       => esc_html__( 'Repository', 'github-repo-selector' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => '',
				'options'     => array_merge( [ '' => esc_html__( 'Select a repository', 'github-repo-selector' ) ], $repo_options ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'selected_repos_list',
			[
				'label'       => esc_html__( 'Repositories List', 'github-repo-selector' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repo_repeater->get_controls(),
				'title_field' => '{{{ repo_name || "Repository" }}}',
				'description' => empty( $repo_options ) ? esc_html__( 'Click Update Repositories first. Then add rows and choose repositories from the dropdowns.', 'github-repo-selector' ) : esc_html__( 'Add one row per repository. Each row uses the same dropdown style as version v1.0.', 'github-repo-selector' ),
				'condition'   => [
					'repo_selection_mode' => 'multiple',
				],
				'render_type' => 'template',
				'frontend_available' => true,
			]
		);

		$this->end_controls_section();

		// Repository Branch Settings
		$this->start_controls_section(
			'section_branch_settings',
			[
				'label' => esc_html__( 'Branch Settings', 'github-repo-selector' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'default_branch',
			[
				'label'       => esc_html__( 'Selected Branch', 'github-repo-selector' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'main',
				'placeholder' => 'main',
				'description' => esc_html__( 'This branch is used first when it exists on the selected repository. The frontend branch dropdown then updates links and README content live.', 'github-repo-selector' ),
				'render_type' => 'template',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'show_branches',
			[
				'label'       => esc_html__( 'Show Branch Selector', 'github-repo-selector' ),
				'type'        => Controls_Manager::SWITCHER,
				'default'     => 'yes',
				'description' => esc_html__( 'Allow users to select branches from dropdown', 'github-repo-selector' ),
				'render_type' => 'template',
				'frontend_available' => true,
			]
		);

		$this->end_controls_section();

		// Content Display Settings
		$this->start_controls_section(
			'section_display_settings',
			[
				'label' => esc_html__( 'Display Options', 'github-repo-selector' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'show_readme',
			[
				'label'   => esc_html__( 'Show README Content', 'github-repo-selector' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'render_type' => 'template',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'show_repo_description',
			[
				'label'   => esc_html__( 'Show Repository Description', 'github-repo-selector' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'render_type' => 'template',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'show_repo_stats',
			[
				'label'   => esc_html__( 'Show Repository Stats', 'github-repo-selector' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'render_type' => 'template',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'show_repo_link',
			[
				'label'   => esc_html__( 'Show GitHub Link Button', 'github-repo-selector' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'render_type' => 'template',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'show_download_button',
			[
				'label'   => esc_html__( 'Show Download ZIP Button', 'github-repo-selector' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'description' => esc_html__( 'Adds a Download button next to View on GitHub. It downloads the selected branch as a ZIP, or the main/default branch if that is selected.', 'github-repo-selector' ),
				'render_type' => 'template',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'readme_max_height',
			[
				'label'     => esc_html__( 'README Max Height (px)', 'github-repo-selector' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 400,
				'render_type' => 'template',
				'frontend_available' => true,
				'condition' => [
					'show_readme' => 'yes',
				],
			]
		);

		$this->end_controls_section();

		// Styling
		$this->start_controls_section(
			'section_style_container',
			[
				'label' => esc_html__( 'Container Style', 'github-repo-selector' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'container_background',
			[
				'label'     => esc_html__( 'Background Color', 'github-repo-selector' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .github-repo-container' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'container_border',
				'label'    => esc_html__( 'Border', 'github-repo-selector' ),
				'selector' => '{{WRAPPER}} .github-repo-container',
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'container_shadow',
				'label'    => esc_html__( 'Box Shadow', 'github-repo-selector' ),
				'selector' => '{{WRAPPER}} .github-repo-container',
			]
		);

		$this->add_control(
			'container_padding',
			[
				'label'      => esc_html__( 'Padding', 'github-repo-selector' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => 20,
					'right'  => 20,
					'bottom' => 20,
					'left'   => 20,
				],
				'selectors'  => [
					'{{WRAPPER}} .github-repo-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Repo Card Styling
		$this->start_controls_section(
			'section_style_repo_card',
			[
				'label' => esc_html__( 'Repository Card Style', 'github-repo-selector' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'repo_card_background',
			[
				'label'     => esc_html__( 'Background Color', 'github-repo-selector' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f6f8fa',
				'selectors' => [
					'{{WRAPPER}} .repo-card' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'repo_card_border',
				'label'    => esc_html__( 'Border', 'github-repo-selector' ),
				'selector' => '{{WRAPPER}} .repo-card',
			]
		);

		$this->add_control(
			'repo_card_padding',
			[
				'label'      => esc_html__( 'Padding', 'github-repo-selector' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => 15,
					'right'  => 15,
					'bottom' => 15,
					'left'   => 15,
				],
				'selectors'  => [
					'{{WRAPPER}} .repo-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'repo_card_margin',
			[
				'label'      => esc_html__( 'Margin', 'github-repo-selector' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => 15,
					'right'  => 0,
					'bottom' => 15,
					'left'   => 0,
				],
				'selectors'  => [
					'{{WRAPPER}} .repo-card' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Title Styling
		$this->start_controls_section(
			'section_style_title',
			[
				'label' => esc_html__( 'Title Style', 'github-repo-selector' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'github-repo-selector' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#0969da',
				'selectors' => [
					'{{WRAPPER}} .repo-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'label'    => esc_html__( 'Typography', 'github-repo-selector' ),
				'selector' => '{{WRAPPER}} .repo-title',
				'fields_options' => [
					'typography' => [ 'default' => 'yes' ],
					'font_size' => [ 'default' => [ 'size' => 20 ] ],
					'font_weight' => [ 'default' => 600 ],
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$username = $this->github_api->get_authenticated_username();
		$selected_repos = [];
		$repo_selection_mode = ! empty( $settings['repo_selection_mode'] ) ? sanitize_text_field( $settings['repo_selection_mode'] ) : 'multiple';

		if ( 'all' === $repo_selection_mode ) {
			// Use the saved dropdown cache first so All Repositories works instantly in Elementor.
			$cached_repo_options = Settings::get_saved_repo_options();
			$selected_repos = array_keys( $cached_repo_options );
		} elseif ( 'single' === $repo_selection_mode ) {
			if ( ! empty( $settings['selected_repo_single'] ) ) {
				$selected_repos = [ sanitize_text_field( $settings['selected_repo_single'] ) ];
			}
		} else {
			if ( ! empty( $settings['selected_repos_list'] ) && is_array( $settings['selected_repos_list'] ) ) {
				foreach ( $settings['selected_repos_list'] as $repo_row ) {
					if ( ! empty( $repo_row['repo_name'] ) ) {
						$selected_repos[] = sanitize_text_field( $repo_row['repo_name'] );
					}
				}
			} elseif ( ! empty( $settings['selected_repos'] ) ) {
				// Backwards compatibility for older v1.0/v1.0 widgets that used a SELECT2 multiple field.
				$selected_repos = array_map( 'sanitize_text_field', (array) $settings['selected_repos'] );
			}
		}
		$selected_repos = array_values( array_unique( array_filter( $selected_repos ) ) );

		if ( empty( $username ) ) {
			echo '<div class="elementor-alert elementor-alert-danger">' .
				sprintf(
					esc_html__( 'No GitHub account is connected. Add a valid token in %s.', 'github-repo-selector' ),
					'<a href="' . esc_url( Settings::get_settings_url() ) . '">' . esc_html__( 'GitHub Repo Selector settings', 'github-repo-selector' ) . '</a>'
				) .
			'</div>';
			return;
		}

		if ( empty( $selected_repos ) ) {
			$repos = $this->github_api->get_user_repos( $username );
			Settings::save_repo_options_from_repos( $repos );
			$selected_repos = wp_list_pluck( $repos, 'name' );
		}

		if ( empty( $selected_repos ) ) {
			echo '<div class="elementor-alert elementor-alert-info">' .
				esc_html__( 'No repositories found for the GitHub account connected to this token.', 'github-repo-selector' ) .
			'</div>';
			return;
		}

		?>
		<div class="github-repo-container">
			<?php
			foreach ( $selected_repos as $repo_name ) {
				$this->render_repo_card( $username, $repo_name, $settings );
			}
			?>
		</div>
		<?php
	}

	private function render_repo_card( $username, $repo_name, $settings ) {
		$repo_details = $this->github_api->get_repo_details( $username, $repo_name );
		$branches = [];

		if ( 'yes' === $settings['show_branches'] ) {
			$branches = $this->github_api->get_repo_branches( $username, $repo_name );
		}

		if ( empty( $repo_details ) ) {
			return;
		}

		$requested_branch = ! empty( $settings['default_branch'] ) ? sanitize_text_field( $settings['default_branch'] ) : '';
		$repo_default_branch = ! empty( $repo_details['default_branch'] ) ? $repo_details['default_branch'] : 'main';
		$branch_names = ! empty( $branches ) ? wp_list_pluck( $branches, 'name' ) : [];

		// Important: use the branch selected/typed in Elementor first when that branch exists.
		// The old version always preferred GitHub's default branch, so selecting a branch still opened main/default.
		if ( ! empty( $requested_branch ) && ( empty( $branch_names ) || in_array( $requested_branch, $branch_names, true ) ) ) {
			$initial_branch = $requested_branch;
		} else {
			$initial_branch = $repo_default_branch;
		}

		$branch_url = $this->build_github_branch_url( $repo_details['html_url'], $initial_branch );
		$download_url = $this->build_github_branch_zip_url( $repo_details['html_url'], $initial_branch );

		?>
		<div class="repo-card">
			<div class="repo-header">
				<h3 class="repo-title">
					<a class="repo-title-link" href="<?php echo esc_url( $branch_url ); ?>" target="_blank" rel="noopener noreferrer">
						<?php echo esc_html( $repo_details['name'] ); ?>
					</a>
				</h3>
				<?php if ( ! empty( $repo_details['language'] ) ) : ?>
					<span class="repo-language"><?php echo esc_html( $repo_details['language'] ); ?></span>
				<?php endif; ?>
			</div>

			<?php if ( 'yes' === $settings['show_repo_description'] && ! empty( $repo_details['description'] ) ) : ?>
				<p class="repo-description"><?php echo esc_html( $repo_details['description'] ); ?></p>
			<?php endif; ?>

			<?php if ( 'yes' === $settings['show_branches'] && ! empty( $branches ) ) : ?>
				<div class="repo-branches">
					<label for="branch-<?php echo esc_attr( $repo_name ); ?>">
						<?php esc_html_e( 'Branch:', 'github-repo-selector' ); ?>
					</label>
					<select id="branch-<?php echo esc_attr( $repo_name ); ?>" class="branch-selector" data-owner="<?php echo esc_attr( $username ); ?>" data-repo="<?php echo esc_attr( $repo_name ); ?>" data-base-url="<?php echo esc_url( $repo_details['html_url'] ); ?>" data-current-branch="<?php echo esc_attr( $initial_branch ); ?>">
						<?php foreach ( $branches as $branch ) : ?>
							<option value="<?php echo esc_attr( $branch['name'] ); ?>" <?php selected( $branch['name'], $initial_branch ); ?>>
								<?php echo esc_html( $branch['name'] ); ?>
								<?php if ( $branch['name'] === $repo_default_branch ) : ?>
									(default)
								<?php endif; ?>
							</option>
						<?php endforeach; ?>
					</select>
				</div>
			<?php endif; ?>

			<?php if ( 'yes' === $settings['show_repo_stats'] ) : ?>
				<div class="repo-stats">
					<span class="stat">
						<span class="stat-label"><?php esc_html_e( 'Stars:', 'github-repo-selector' ); ?></span>
						<span class="stat-value"><?php echo number_format( $repo_details['stargazers_count'] ); ?></span>
					</span>
					<span class="stat">
						<span class="stat-label"><?php esc_html_e( 'Forks:', 'github-repo-selector' ); ?></span>
						<span class="stat-value"><?php echo number_format( $repo_details['forks_count'] ); ?></span>
					</span>
					<?php if ( ! $repo_details['private'] ) : ?>
						<span class="stat">
							<span class="stat-label"><?php esc_html_e( 'Watchers:', 'github-repo-selector' ); ?></span>
							<span class="stat-value"><?php echo number_format( $repo_details['watchers_count'] ); ?></span>
						</span>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<?php if ( 'yes' === $settings['show_readme'] ) : ?>
				<div class="repo-readme-container" style="max-height: <?php echo intval( $settings['readme_max_height'] ); ?>px; overflow-y: auto;">
					<?php
					$readme = $this->github_api->get_repo_readme( $username, $repo_name, $initial_branch );
					
					if ( ! empty( $readme ) ) {
						// Convert markdown to HTML (basic)
						$readme = $this->markdown_to_html( $readme );
						echo wp_kses_post( $readme );
					} else {
						echo '<p class="repo-no-readme">' . esc_html__( 'No README available', 'github-repo-selector' ) . '</p>';
					}
					?>
				</div>
			<?php endif; ?>

			<?php if ( 'yes' === $settings['show_repo_link'] || ( isset( $settings['show_download_button'] ) && 'yes' === $settings['show_download_button'] ) ) : ?>
				<div class="repo-footer">
					<?php if ( 'yes' === $settings['show_repo_link'] ) : ?>
						<a href="<?php echo esc_url( $branch_url ); ?>" class="repo-button repo-view-button" target="_blank" rel="noopener noreferrer">
							<?php esc_html_e( 'View on GitHub', 'github-repo-selector' ); ?>
						</a>
					<?php endif; ?>
					<?php if ( isset( $settings['show_download_button'] ) && 'yes' === $settings['show_download_button'] ) : ?>
						<a href="<?php echo esc_url( $download_url ); ?>" class="repo-button repo-download-button" target="_blank" rel="noopener noreferrer" download>
							<?php esc_html_e( 'Download ZIP', 'github-repo-selector' ); ?>
						</a>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}


	private function build_github_branch_url( $base_url, $branch ) {
		$base_url = untrailingslashit( $base_url );
		$branch_parts = array_map( 'rawurlencode', explode( '/', (string) $branch ) );
		return $base_url . '/tree/' . implode( '/', $branch_parts );
	}

	private function build_github_branch_zip_url( $base_url, $branch ) {
		$base_url = untrailingslashit( $base_url );
		$branch_parts = array_map( 'rawurlencode', explode( '/', (string) $branch ) );
		return $base_url . '/archive/refs/heads/' . implode( '/', $branch_parts ) . '.zip';
	}

	/**
	 * Basic markdown to HTML conversion
	 */
	private function markdown_to_html( $markdown ) {
		// Convert headers
		$markdown = preg_replace( '/^### (.*?)$/m', '<h3>$1</h3>', $markdown );
		$markdown = preg_replace( '/^## (.*?)$/m', '<h2>$1</h2>', $markdown );
		$markdown = preg_replace( '/^# (.*?)$/m', '<h1>$1</h1>', $markdown );

		// Convert bold
		$markdown = preg_replace( '/\*\*(.*?)\*\*/', '<strong>$1</strong>', $markdown );
		$markdown = preg_replace( '/__(.+?)__/', '<strong>$1</strong>', $markdown );

		// Convert italic
		$markdown = preg_replace( '/\*(.*?)\*/', '<em>$1</em>', $markdown );
		$markdown = preg_replace( '/_(.+?)_/', '<em>$1</em>', $markdown );

		// Convert line breaks
		$markdown = nl2br( $markdown );

		// Convert links
		$markdown = preg_replace( '/\[(.*?)\]\((.*?)\)/', '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>', $markdown );

		// Convert code blocks
		$markdown = preg_replace( '/`([^`]+)`/', '<code>$1</code>', $markdown );

		// Convert lists
		$markdown = preg_replace( '/^\- (.*?)$/m', '<li>$1</li>', $markdown );
		$markdown = preg_replace( '/(<li>.*<\/li>)/s', '<ul>$1</ul>', $markdown );

		return $markdown;
	}

	protected function content_template() {
		$repo_options = Settings::get_saved_repo_options();
		$repo_names = array_values( array_keys( $repo_options ) );
		?>
		<#
		var repoMode = settings.repo_selection_mode || 'multiple';
		var selectedRepos = [];
		var cachedRepos = <?php echo wp_json_encode( $repo_names ); ?> || [];
		var branch = settings.default_branch || 'main';
		var maxHeight = settings.readme_max_height || 400;
		var showDescription = settings.show_repo_description !== 'yes' ? false : true;
		var showStats = settings.show_repo_stats !== 'yes' ? false : true;
		var showReadme = settings.show_readme !== 'yes' ? false : true;
		var showBranches = settings.show_branches !== 'yes' ? false : true;
		var showGithub = settings.show_repo_link !== 'yes' ? false : true;
		var showDownload = settings.show_download_button !== 'yes' ? false : true;

		function cleanRepoName( value ) {
			return value ? String( value ) : '';
		}

		function repoBranchUrl( repo, selectedBranch ) {
			var owner = '<?php echo esc_js( $this->github_api->get_authenticated_username() ?: 'your-github-account' ); ?>';
			var encodedBranch = String( selectedBranch || 'main' ).split( '/' ).map( encodeURIComponent ).join( '/' );
			return 'https://github.com/' + owner + '/' + encodeURIComponent( repo ) + '/tree/' + encodedBranch;
		}

		function repoZipUrl( repo, selectedBranch ) {
			var owner = '<?php echo esc_js( $this->github_api->get_authenticated_username() ?: 'your-github-account' ); ?>';
			var encodedBranch = String( selectedBranch || 'main' ).split( '/' ).map( encodeURIComponent ).join( '/' );
			return 'https://github.com/' + owner + '/' + encodeURIComponent( repo ) + '/archive/refs/heads/' + encodedBranch + '.zip';
		}

		if ( repoMode === 'all' ) {
			selectedRepos = cachedRepos.slice( 0 );
		} else if ( repoMode === 'single' ) {
			if ( settings.selected_repo_single ) {
				selectedRepos = [ cleanRepoName( settings.selected_repo_single ) ];
			}
		} else if ( settings.selected_repos_list && settings.selected_repos_list.length ) {
			_.each( settings.selected_repos_list, function( row ) {
				if ( row && row.repo_name ) {
					selectedRepos.push( cleanRepoName( row.repo_name ) );
				}
			} );
		}

		selectedRepos = _.uniq( _.filter( selectedRepos ) );
		if ( ! selectedRepos.length ) {
			selectedRepos = [ 'Select a repository' ];
		}
		#>
		<div class="github-repo-container github-repo-selector-live-preview" data-preview-mode="{{ repoMode }}">
			<# _.each( selectedRepos, function( repoName ) { 
				var isPlaceholder = repoName === 'Select a repository';
				var viewUrl = isPlaceholder ? '#' : repoBranchUrl( repoName, branch );
				var zipUrl = isPlaceholder ? '#' : repoZipUrl( repoName, branch );
			#>
				<div class="repo-card">
					<div class="repo-header">
						<h3 class="repo-title">
							<# if ( isPlaceholder ) { #>
								{{{ repoName }}}
							<# } else { #>
								<a class="repo-title-link" href="{{ viewUrl }}" target="_blank" rel="noopener noreferrer">{{{ repoName }}}</a>
							<# } #>
						</h3>
						<span class="repo-language">Live preview</span>
					</div>

					<# if ( showDescription ) { #>
						<p class="repo-description">Repository description will show here from GitHub on the live page.</p>
					<# } #>

					<# if ( showBranches ) { #>
						<div class="repo-branches">
							<label>Branch:</label>
							<select class="branch-selector">
								<option selected>{{{ branch }}}</option>
							</select>
						</div>
					<# } #>

					<# if ( showStats ) { #>
						<div class="repo-stats">
							<span class="stat"><span class="stat-label">Stars:</span> <span class="stat-value">0</span></span>
							<span class="stat"><span class="stat-label">Forks:</span> <span class="stat-value">0</span></span>
						</div>
					<# } #>

					<# if ( showReadme ) { #>
						<div class="repo-readme-container" style="max-height: {{ maxHeight }}px; overflow-y: auto;">
							<p><strong>README preview</strong></p>
							<p>The real README loads from GitHub on the frontend. This preview updates live while you change repository mode, repo selection, branch, buttons and display options.</p>
						</div>
					<# } #>

					<# if ( showGithub || showDownload ) { #>
						<div class="repo-footer">
							<# if ( showGithub ) { #>
								<a href="{{ viewUrl }}" class="repo-button repo-view-button" target="_blank" rel="noopener noreferrer">View on GitHub</a>
							<# } #>
							<# if ( showDownload ) { #>
								<a href="{{ zipUrl }}" class="repo-button repo-download-button" target="_blank" rel="noopener noreferrer" download>Download ZIP</a>
							<# } #>
						</div>
					<# } #>
				</div>
			<# } ); #>
		</div>
		<?php
	}
}
