<?php
/**
 * Plugin Name: CM Liveblog
 * Plugin URI: https://connormoizer.com
 * Version: 1.0.1
 * Author: ConnorMoizer.com
 * Author URI: https://connormoizer.com
 * Description: Plug & play live blog system with ACF repeater, real-time updates, and Elementor-compatible frontend rendering.
 */

if (!defined('ABSPATH')) exit;

/* CPT */
add_action('init', function(){
    register_post_type('cm_liveblog', [
        'label'=>'Live Blogs',
        'public'=>true,
        'rewrite'=>['slug'=>'live-blog'],
        'menu_icon'=>'dashicons-megaphone',
        'supports'=>['title','author']
    ]);
});
