<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Sidebar_Menu_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'sidebar_menu';
    }

    public function get_title() {
        return 'Sidebar Menu';
    }

    public function get_icon() {
        return 'eicon-menu-bar';
    }

    public function get_categories() {
        return [ 'general' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'section_content',
            [
                'label' => __( 'Menu', 'sidebar-menu' ),
            ]
        );

        $menus = wp_get_nav_menus();
        $options = [];
        foreach ( $menus as $menu ) {
            $options[$menu->term_id] = $menu->name;
        }

        $this->add_control(
            'menu_id',
            [
                'label' => __( 'Select Menu', 'sidebar-menu' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => $options,
            ]
        );

        $this->add_control(
            'active_color',
            [
                'label' => __( 'Active Border Color', 'sidebar-menu' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#0073e6',
            ]
        );

        $this->add_control(
            'inactive_color',
            [
                'label' => __( 'Inactive Border Color', 'sidebar-menu' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#e5e5e5',
            ]
        );

        $this->add_control(
            'divider_color',
            [
                'label' => __( 'Divider Color', 'sidebar-menu' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#e5e5e5',
            ]
        );

        $this->add_control(
            'side',
            [
                'label' => __( 'Active Side', 'sidebar-menu' ),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'sidebar-menu' ),
                        'icon' => 'eicon-h-align-left',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'sidebar-menu' ),
                        'icon' => 'eicon-h-align-right',
                    ],
                ],
                'default' => 'left',
            ]
        );

        $this->add_control(
            'border_thickness',
            [
                'label' => __( 'Border Thickness (px)', 'sidebar-menu' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 1,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'text_typography',
                'selector' => '{{WRAPPER}} .sidebar-menu li a',
            ]
        );

        $this->add_control(
            'text_color',
            [
                'label' => __( 'Text Color', 'sidebar-menu' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#333333',
                'selectors' => [
                    '{{WRAPPER}} .sidebar-menu li a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'active_text_color',
            [
                'label' => __( 'Active Text Color', 'sidebar-menu' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#0073e6',
                'selectors' => [
                    '{{WRAPPER}} .sidebar-menu li.active a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'hover_text_color',
            [
                'label' => __( 'Hover Text Color', 'sidebar-menu' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#555555',
                'selectors' => [
                    '{{WRAPPER}} .sidebar-menu li a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $menu_items = wp_get_nav_menu_items( $settings['menu_id'] );

        if ( ! $menu_items ) return;

        $side = $settings['side'];
        $active_color = $settings['active_color'];
        $inactive_color = $settings['inactive_color'];
        $divider_color = $settings['divider_color'];
        $thickness = $settings['border_thickness'];

        echo "<ul class='sidebar-menu {$side}'>";
        $count = count($menu_items);
        $i = 0;
        foreach ( $menu_items as $item ) {
            $i++;
            $active = ($item->object_id == get_queried_object_id()) ? 'active' : 'inactive';
            $divider = ($i < $count) ? "border-bottom: {$thickness}px solid {$divider_color};" : "";
            echo "<li class='{$active}' style='{$divider}'><a href='{$item->url}'>{$item->title}</a></li>";
        }
        echo "</ul>";

        echo "<style>
        .sidebar-menu { list-style:none; padding:0; margin:0; }
        .sidebar-menu li { margin:0; padding:10px; border:0; }
        .sidebar-menu.left li { border-right: none; border-left: {$thickness}px solid transparent; }
        .sidebar-menu.right li { border-left: none; border-right: {$thickness}px solid transparent; }
        .sidebar-menu.left li.inactive { border-left-color: {$inactive_color}; }
        .sidebar-menu.left li.active { border-left-color: {$active_color}; }
        .sidebar-menu.right li.inactive { border-right-color: {$inactive_color}; }
        .sidebar-menu.right li.active { border-right-color: {$active_color}; }
        </style>";
    }
}
?>
