<?php
/*
Plugin Name: Sidebar Menu (Dev v1.8.1)
Description: Elementor Sidebar Menu styled like Elliott Hudson (default) with full customization controls.
Version: 1.8.1
Author: Connor Moizer
*/

if ( ! defined( 'ABSPATH' ) ) exit;

// Register widget
function sidebar_menu_register_widget( $widgets_manager ) {
    require_once( __DIR__ . '/widget-sidebar-menu.php' );
    $widgets_manager->register( new \Sidebar_Menu_Widget() );
}
add_action( 'elementor/widgets/register', 'sidebar_menu_register_widget' );

// Cleanup old versions on activation
function sidebar_menu_activate() {
    if (!function_exists('get_plugins')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }
    $all_plugins = get_plugins();
    foreach ($all_plugins as $plugin_file => $plugin_data) {
        if (strpos($plugin_data['Name'], 'Sidebar Menu') !== false && $plugin_data['Version'] !== '1.8.1') {
            deactivate_plugins($plugin_file);
        }
    }
}
register_activation_hook(__FILE__, 'sidebar_menu_activate');
?>
