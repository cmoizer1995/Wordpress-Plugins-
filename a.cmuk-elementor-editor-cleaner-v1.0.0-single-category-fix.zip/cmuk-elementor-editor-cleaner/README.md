# CMUK Elementor Editor Cleaner v1.0.0 Panel-Only Safe Build

This build lets Elementor open normally, then hides selected widget categories/widgets visually inside the left Elementor panel.

It does not unregister Elementor widgets.

Use:
Settings → CMUK Elementor Cleaner

Locked as v1.0.0 until Connor Moizer explicitly asks for a version change.


## Dynamic Elementor Detection Update

This build now scans Elementor live and automatically lists:
- third-party widget categories
- Link in Bio categories
- addon pack categories
- custom plugin categories
- dynamically registered Elementor widgets

The cleaner panel now reflects whatever is currently installed on the website.


## Collapsed categories update

Added a safe option: "Collapse widget categories when editor opens".

This does not disable Elementor. It only closes the widget category panels after Elementor has loaded, so the editor starts cleaner and users can manually open the categories they need.


## Single category fix

The settings page now always includes Elementor Theme Builder categories like:
- Single
- Archive
- Site
- Theme
- Loop

The editor cleaner also hides categories by visible panel title, so the open "Single" section shown in Elementor can be hidden by ticking Single.
