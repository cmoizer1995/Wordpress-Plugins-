<?php
/**
 * Plugin Name: CMUK Elementor Editor Cleaner
 * Plugin URI: https://connormoizer.com
 * Description: Safely white-label and visually clean the Elementor editor panel without stopping Elementor from opening.
 * Version: 1.0.0
 * Author: Connor Moizer
 * Text Domain: cmuk-elementor-editor-cleaner
 */

if (!defined('ABSPATH')) { exit; }

define('CMUK_EEC_VERSION', '1.0.0');
define('CMUK_EEC_PATH', plugin_dir_path(__FILE__));
define('CMUK_EEC_URL', plugin_dir_url(__FILE__));

final class CMUK_Elementor_Editor_Cleaner {
    private $option_name = 'cmuk_eec_settings';

    public function __construct() {
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'admin_assets'));
        add_action('elementor/editor/after_enqueue_styles', array($this, 'editor_styles'));
        add_action('elementor/editor/after_enqueue_scripts', array($this, 'editor_scripts'));
        add_filter('admin_footer_text', array($this, 'admin_footer_text'), 99);
    }

    public function defaults() {
        return array(
            'enabled' => 0,
            'brand_name' => 'CMUK Editor',
            'brand_colour' => '#1d70b8',
            'hide_elementor_logo' => 0,
            'hide_upgrade_buttons' => 0,
            'hide_finder' => 0,
            'hide_notes' => 0,
            'hide_ai' => 0,
            'hide_responsive_mode' => 0,
            'hide_help_links' => 0,
            'collapse_categories_on_open' => 1,
            'hide_categories' => array(),
            'hide_widgets' => array(),
            'custom_css' => '',
            'admin_footer' => 'Created by Connor Moizer',
        );
    }

    public function get_settings() {
        $saved = get_option($this->option_name, array());
        if (!is_array($saved)) { $saved = array(); }
        return wp_parse_args($saved, $this->defaults());
    }

    public function enabled() {
        $s = $this->get_settings();
        return !empty($s['enabled']);
    }

    public function admin_menu() {
        add_options_page(
            __('CMUK Elementor Cleaner', 'cmuk-elementor-editor-cleaner'),
            __('CMUK Elementor Cleaner', 'cmuk-elementor-editor-cleaner'),
            'manage_options',
            'cmuk-elementor-editor-cleaner',
            array($this, 'settings_page')
        );
    }

    public function register_settings() {
        register_setting('cmuk_eec_group', $this->option_name, array($this, 'sanitize_settings'));
    }

    public function sanitize_settings($input) {
        $defaults = $this->defaults();
        $out = array();

        $out['enabled'] = !empty($input['enabled']) ? 1 : 0;
        $out['brand_name'] = sanitize_text_field($input['brand_name'] ?? $defaults['brand_name']);
        $out['brand_colour'] = sanitize_hex_color($input['brand_colour'] ?? $defaults['brand_colour']);
        if (!$out['brand_colour']) { $out['brand_colour'] = $defaults['brand_colour']; }

        foreach (array('hide_elementor_logo','hide_upgrade_buttons','hide_finder','hide_notes','hide_ai','hide_responsive_mode','hide_help_links','collapse_categories_on_open') as $key) {
            $out[$key] = !empty($input[$key]) ? 1 : 0;
        }

        $out['hide_categories'] = array();
        if (!empty($input['hide_categories']) && is_array($input['hide_categories'])) {
            $out['hide_categories'] = array_map('sanitize_key', $input['hide_categories']);
        }

        $out['hide_widgets'] = array();
        if (!empty($input['hide_widgets']) && is_array($input['hide_widgets'])) {
            $out['hide_widgets'] = array_map('sanitize_key', $input['hide_widgets']);
        }

        $out['custom_css'] = wp_strip_all_tags($input['custom_css'] ?? '');
        $out['admin_footer'] = sanitize_text_field($input['admin_footer'] ?? $defaults['admin_footer']);

        return $out;
    }

    
    public function known_categories() {
        $categories = array(
            'basic' => 'Basic',
            'general' => 'General',
            'pro-elements' => 'Pro',
            'theme-elements' => 'Theme',
            'woocommerce-elements' => 'WooCommerce',
            'wordpress' => 'WordPress',
            'site' => 'Site',
            'single' => 'Single',
            'archive' => 'Archive',
            'loop' => 'Loop',
            'theme' => 'Theme',
            'favorites' => 'Favorites',
            'cmuk-components' => 'CMUK Components',
            'cmuk-patterns' => 'CMUK Patterns',
            'cmuk-styles' => 'CMUK Styles',
        );

        $cached = get_option('cmuk_eec_discovered_categories', array());
        if (is_array($cached)) {
            foreach ($cached as $id => $label) {
                $id = sanitize_key($id);
                if ($id) {
                    $categories[$id] = $label ?: $id;
                }
            }
        }

        if (did_action('elementor/loaded') && class_exists('\Elementor\Plugin')) {
            try {
                $manager = \Elementor\Plugin::$instance->elements_manager;
                if ($manager && method_exists($manager, 'get_categories')) {
                    $raw = $manager->get_categories();
                    if (is_array($raw)) {
                        foreach ($raw as $id => $data) {
                            $label = $id;
                            if (is_array($data) && !empty($data['title'])) {
                                $label = $data['title'];
                            }
                            $categories[$id] = $label;
                        }
                    }
                }
            } catch (\Throwable $e) {}
        }

        asort($categories);
        return $categories;
    }


    public function known_widgets() {
        $widgets = array();

        if ( did_action( 'elementor/loaded' ) && class_exists('\Elementor\Plugin') ) {
            try {
                $manager = \Elementor\Plugin::$instance->widgets_manager;

                if ($manager && method_exists($manager, 'get_widget_types')) {
                    $raw = $manager->get_widget_types();

                    if (is_array($raw)) {
                        foreach ($raw as $id => $widget) {
                            $label = $id;

                            if (is_object($widget) && method_exists($widget, 'get_title')) {
                                $label = $widget->get_title();
                            }

                            $widgets[$id] = $label;
                        }
                    }
                }
            } catch (\Throwable $e) {
                // silent fail
            }
        }

        if (empty($widgets)) {
            $widgets = array(
                'heading' => 'Elementor Heading',
                'image' => 'Elementor Image',
                'text-editor' => 'Elementor Text Editor',
                'button' => 'Elementor Button',
            );
        }

        asort($widgets);

        return $widgets;
    }

public function admin_assets($hook) {
        if ($hook !== 'settings_page_cmuk-elementor-editor-cleaner') { return; }
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');
        wp_enqueue_style('cmuk-eec-admin', CMUK_EEC_URL . 'assets/css/admin.css', array(), CMUK_EEC_VERSION);
        wp_enqueue_script('cmuk-eec-admin', CMUK_EEC_URL . 'assets/js/admin.js', array('jquery','wp-color-picker'), CMUK_EEC_VERSION, true);
    }

    public function settings_page() {
        $s = $this->get_settings();
        ?>
        <div class="wrap cmuk-eec-wrap">
            <h1>CMUK Elementor Editor Cleaner</h1>
            <p class="description">Safe mode: this plugin does not unregister Elementor widgets. It only hides selected items inside the left editor panel after Elementor has opened.</p>

            <form method="post" action="options.php">
                <?php settings_fields('cmuk_eec_group'); ?>

                <div class="cmuk-eec-card">
                    <h2>Main Settings</h2>
                    <label class="cmuk-eec-toggle">
                        <input type="checkbox" name="<?php echo esc_attr($this->option_name); ?>[enabled]" value="1" <?php checked($s['enabled']); ?>>
                        <span>Enable cleaner</span>
                    </label>

                    <table class="form-table">
                        <tr>
                            <th><label>Editor brand name</label></th>
                            <td><input type="text" class="regular-text" name="<?php echo esc_attr($this->option_name); ?>[brand_name]" value="<?php echo esc_attr($s['brand_name']); ?>"></td>
                        </tr>
                        <tr>
                            <th><label>Brand colour</label></th>
                            <td><input type="text" class="cmuk-colour-field" name="<?php echo esc_attr($this->option_name); ?>[brand_colour]" value="<?php echo esc_attr($s['brand_colour']); ?>"></td>
                        </tr>
                        <tr>
                            <th><label>Admin footer text</label></th>
                            <td><input type="text" class="regular-text" name="<?php echo esc_attr($this->option_name); ?>[admin_footer]" value="<?php echo esc_attr($s['admin_footer']); ?>"></td>
                        </tr>
                    </table>
                </div>

                <div class="cmuk-eec-grid">
                    <div class="cmuk-eec-card">
                        <h2>Visual Cleanup</h2>
                        <?php
                        $toggles = array(
                            'hide_elementor_logo' => 'Hide Elementor logo text',
                            'hide_upgrade_buttons' => 'Hide upgrade/pro buttons',
                            'hide_finder' => 'Hide Finder button',
                            'hide_notes' => 'Hide Notes button',
                            'hide_ai' => 'Hide AI buttons',
                            'hide_responsive_mode' => 'Hide responsive mode button',
                            'hide_help_links' => 'Hide help/learn links',
                            'collapse_categories_on_open' => 'Collapse widget categories when editor opens',
                        );
                        foreach ($toggles as $key => $label) :
                        ?>
                        <label class="cmuk-eec-toggle">
                            <input type="checkbox" name="<?php echo esc_attr($this->option_name); ?>[<?php echo esc_attr($key); ?>]" value="1" <?php checked($s[$key]); ?>>
                            <span><?php echo esc_html($label); ?></span>
                        </label>
                        <?php endforeach; ?>
                    </div>

                    <div class="cmuk-eec-card">
                        <h2>Hide Widget Categories</h2>
                        <p class="description">This hides categories visually in the Elementor panel only. Elementor still opens normally.</p>
                        <div class="cmuk-eec-checklist">
                            <?php foreach ($this->known_categories() as $id => $label) : ?>
                            <label>
                                <input type="checkbox" name="<?php echo esc_attr($this->option_name); ?>[hide_categories][]" value="<?php echo esc_attr($id); ?>" <?php checked(in_array($id, $s['hide_categories'], true)); ?>>
                                <span><?php echo esc_html($label); ?> <code><?php echo esc_html($id); ?></code></span>
                            </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <div class="cmuk-eec-card">
                    <h2>Hide Individual Widgets</h2>
                    <p class="description">This hides widgets visually in the left panel only. It does not disable Elementor or existing pages.</p>
                    <div class="cmuk-eec-widget-grid">
                        <?php foreach ($this->known_widgets() as $id => $label) : ?>
                        <label>
                            <input type="checkbox" name="<?php echo esc_attr($this->option_name); ?>[hide_widgets][]" value="<?php echo esc_attr($id); ?>" <?php checked(in_array($id, $s['hide_widgets'], true)); ?>>
                            <span><?php echo esc_html($label); ?> <code><?php echo esc_html($id); ?></code></span>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="cmuk-eec-card">
                    <h2>Custom Editor CSS</h2>
                    <p class="description">Loaded only inside the Elementor editor. Avoid hiding #elementor-editor-wrapper or #elementor-panel.</p>
                    <textarea class="large-text code" rows="8" name="<?php echo esc_attr($this->option_name); ?>[custom_css]"><?php echo esc_textarea($s['custom_css']); ?></textarea>
                </div>

                <?php submit_button('Save cleaner settings'); ?>
            </form>
        </div>
        <?php
    }

    public function editor_styles() {
        if (!$this->enabled()) { return; }

        $s = $this->get_settings();
        wp_enqueue_style('cmuk-eec-editor', CMUK_EEC_URL . 'assets/css/editor.css', array(), CMUK_EEC_VERSION);

        $css = ':root{--cmuk-eec-brand:' . esc_html($s['brand_colour']) . ';}';

        if (!empty($s['hide_elementor_logo'])) {
            $css .= '#elementor-panel-header-title,#elementor-panel-header-logo{display:none!important;}';
        }
        if (!empty($s['hide_upgrade_buttons'])) {
            $css .= '.elementor-panel a[href*="go.elementor.com"],.elementor-panel a[href*="upgrade"]{display:none!important;}';
        }
        if (!empty($s['hide_finder'])) {
            $css .= '#elementor-panel-footer-finder{display:none!important;}';
        }
        if (!empty($s['hide_notes'])) {
            $css .= '#elementor-panel-footer-notes{display:none!important;}';
        }
        if (!empty($s['hide_ai'])) {
            $css .= '.elementor-panel .e-ai-button,.elementor-panel .elementor-control-ai,.elementor-panel .eicon-ai{display:none!important;}';
        }
        if (!empty($s['hide_responsive_mode'])) {
            $css .= '#elementor-panel-footer-responsive{display:none!important;}';
        }
        if (!empty($s['hide_help_links'])) {
            $css .= '#elementor-panel-footer-help,.elementor-panel a[href*="docs"],.elementor-panel a[href*="help"]{display:none!important;}';
        }

        foreach ($s['hide_categories'] as $cat) {
            $cat = sanitize_html_class($cat);
            $css .= '#elementor-panel-category-' . $cat . ',';
            $css .= '#elementor-panel-elements-category-' . $cat . ',';
            $css .= '.elementor-panel-category-' . $cat . ',';
            $css .= '.elementor-panel-category[data-category="' . $cat . '"],';
            $css .= '.elementor-panel-category[data-tab="' . $cat . '"],';
            $css .= '.elementor-panel-category[data-id="' . $cat . '"],';
            $css .= '.elementor-panel-category[data-category-name="' . $cat . '"]{display:none!important;}';
        }

        foreach ($s['hide_widgets'] as $widget) {
            $widget = sanitize_html_class($widget);
            $css .= '#elementor-panel .elementor-element-wrapper[data-widget_type="' . $widget . '.default"],#elementor-panel .elementor-element-wrapper[data-widget_type="' . $widget . '"]{display:none!important;}';
        }

        if (!empty($s['custom_css'])) {
            $css .= "\n" . $s['custom_css'];
        }

        wp_add_inline_style('cmuk-eec-editor', $css);
    }

    public function editor_scripts() {
        if (!$this->enabled()) { return; }

        $s = $this->get_settings();

        wp_enqueue_script('cmuk-eec-editor', CMUK_EEC_URL . 'assets/js/editor.js', array('jquery'), CMUK_EEC_VERSION, true);
        wp_localize_script('cmuk-eec-editor', 'CMUK_EEC', array(
            'brandName' => $s['brand_name'],
            'hiddenWidgets' => array_values($s['hide_widgets']),
            'hiddenCategories' => array_values($s['hide_categories']),
            'collapseCategories' => !empty($s['collapse_categories_on_open']),
        ));
    }

    public function admin_footer_text($text) {
        if (!$this->enabled()) { return $text; }
        $s = $this->get_settings();
        return !empty($s['admin_footer']) ? esc_html($s['admin_footer']) : $text;
    }
}

new CMUK_Elementor_Editor_Cleaner();
