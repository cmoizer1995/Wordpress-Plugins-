(function($){
  function slugify(text){
    return String(text || '').toLowerCase().trim().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'');
  }

  function hideCategories(){
    if(typeof CMUK_EEC === 'undefined' || !Array.isArray(CMUK_EEC.hiddenCategories)) return;

    CMUK_EEC.hiddenCategories.forEach(function(cat){
      cat = String(cat || '').toLowerCase();

      $('#elementor-panel-category-'+cat+', #elementor-panel-elements-category-'+cat+', .elementor-panel-category-'+cat).hide();
      $('#elementor-panel .elementor-panel-category[data-category="'+cat+'"], #elementor-panel .elementor-panel-category[data-tab="'+cat+'"], #elementor-panel .elementor-panel-category[data-id="'+cat+'"], #elementor-panel .elementor-panel-category[data-category-name="'+cat+'"]').hide();

      $('#elementor-panel-elements .elementor-panel-category, #elementor-panel .elementor-panel-category').each(function(){
        var $category = $(this);
        var title = $category.find('.elementor-panel-category-title').first().text();
        var id = $category.attr('id') || '';
        var classes = $category.attr('class') || '';
        var dataCategory = $category.attr('data-category') || $category.attr('data-tab') || $category.attr('data-id') || '';

        if (
          slugify(title) === cat ||
          slugify(id).indexOf(cat) !== -1 ||
          slugify(classes).indexOf(cat) !== -1 ||
          slugify(dataCategory) === cat
        ) {
          $category.hide();
        }
      });
    });
  }

  function hideWidgets(){
    if(typeof CMUK_EEC === 'undefined' || !Array.isArray(CMUK_EEC.hiddenWidgets)) return;

    CMUK_EEC.hiddenWidgets.forEach(function(widget){
      $('#elementor-panel .elementor-element-wrapper[data-widget_type="'+widget+'.default"], #elementor-panel .elementor-element-wrapper[data-widget_type="'+widget+'"]').hide();
    });
  }

  function collapseCategories(){
    if(typeof CMUK_EEC === 'undefined' || !CMUK_EEC.collapseCategories) return;

    $('#elementor-panel-elements .elementor-panel-category').each(function(){
      var $category = $(this);
      if ($category.attr('data-cmuk-initial-collapsed') === 'yes') return;

      $category.attr('data-cmuk-initial-collapsed','yes');

      var $items = $category.find('.elementor-panel-category-items, .elementor-panel-category-elements, .elementor-panel-category-content').first();
      var $title = $category.find('.elementor-panel-category-title').first();

      if($items.length) $items.hide();
      $category.removeClass('elementor-active elementor-opened active opened');
      $title.attr('aria-expanded','false');
    });
  }

  function brand(){
    if(typeof CMUK_EEC === 'undefined') return;
    if(CMUK_EEC.brandName && !$('#cmuk-eec-brand-label').length && $('#elementor-panel-header').length){
      $('#elementor-panel-header').prepend('<div id="cmuk-eec-brand-label">'+CMUK_EEC.brandName+'</div>');
    }
  }

  function run(){
    if(!$('#elementor-panel').length) return;
    brand();
    hideCategories();
    hideWidgets();
    collapseCategories();
  }

  $(window).on('elementor:init', function(){
    setTimeout(run,700);
    setTimeout(run,1500);
    setTimeout(run,3000);
  });
  $(document).on('ready click keyup', function(){ setTimeout(run,250); });
})(jQuery);
