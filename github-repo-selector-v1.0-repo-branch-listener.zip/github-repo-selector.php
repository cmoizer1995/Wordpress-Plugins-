<?php
/**
 * Plugin Name: GitHub Repo Selector for Elementor
 * Plugin URI: https://github.com/yourusername/github-repo-selector
 * Description: Display selected GitHub repositories and branches as an Elementor widget
 * Version: v1.0
 * Author: Connor Moizer
 * Author URI: https://connormoizer.com
 * License: GPL v3
 * License URI: https://www.gnu.org/licenses/gpl-3.0.html
 * Text Domain: github-repo-selector
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

define( 'GITHUB_REPO_SELECTOR_VERSION', 'v1.0' );
define( 'GITHUB_REPO_SELECTOR_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'GITHUB_REPO_SELECTOR_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/**
 * Check if Elementor is active
 */
function github_repo_selector_is_elementor_active() {
	return did_action( 'elementor/loaded' );
}

/**
 * Initialize the plugin
 */
function github_repo_selector_init() {
	// Load text domain
	load_plugin_textdomain( 'github-repo-selector', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

	// Load required files
	require_once GITHUB_REPO_SELECTOR_PLUGIN_DIR . 'includes/class-github-api.php';
	require_once GITHUB_REPO_SELECTOR_PLUGIN_DIR . 'includes/class-settings.php';
	require_once GITHUB_REPO_SELECTOR_PLUGIN_DIR . 'includes/class-ajax-handler.php';

	// Register Elementor widget
	if ( did_action( 'elementor/loaded' ) ) {
		add_action( 'elementor/widgets/register', 'github_repo_selector_register_widgets' );
	}
}
add_action( 'plugins_loaded', 'github_repo_selector_init' );

/**
 * Register Elementor widget
 */
function github_repo_selector_register_widgets( $widgets_manager ) {
	require_once GITHUB_REPO_SELECTOR_PLUGIN_DIR . 'widgets/class-github-repo-widget.php';
	$widgets_manager->register( new \GitHub_Repo_Selector\Widgets\GitHub_Repo_Widget() );
}

/**
 * Add admin menu for settings
 */
function github_repo_selector_add_admin_menu() {
	add_options_page(
		__( 'GitHub Repo Selector', 'github-repo-selector' ),
		__( 'GitHub Repo Selector', 'github-repo-selector' ),
		'manage_options',
		'github-repo-selector',
		'github_repo_selector_settings_page'
	);
}
add_action( 'admin_menu', 'github_repo_selector_add_admin_menu' );

/**
 * Display settings page
 */
function github_repo_selector_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	if ( isset( $_POST['submit'] ) ) {
		check_admin_referer( 'github_repo_selector_nonce' );
		update_option( 'github_repo_selector_token', sanitize_text_field( $_POST['github_token'] ?? '' ) );
		$api = new \GitHub_Repo_Selector\GitHub_API();
		$api->clear_cache( '', '', false );
		echo '<div class="notice notice-success"><p>' . __( 'Settings saved. GitHub account cache refreshed.', 'github-repo-selector' ) . '</p></div>';
	}

	if ( isset( $_POST['github_repo_selector_update_cache'] ) ) {
		check_admin_referer( 'github_repo_selector_update_cache_nonce' );
		$api = new \GitHub_Repo_Selector\GitHub_API();
		$api->clear_cache( '', '', false );
		$username = $api->get_authenticated_username();

		if ( empty( $username ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'Could not detect the GitHub account from the saved token. Save/check the token first.', 'github-repo-selector' ) . '</p></div>';
		} else {
			$refresh = $api->refresh_repositories_and_branches( $username );
			$repos = $refresh['repos'];
			if ( ! empty( $repos ) && is_array( $repos ) ) {
				$options = \GitHub_Repo_Selector\Settings::save_repo_options_from_repos( $repos );
				echo '<div class="notice notice-success"><p>' . sprintf( esc_html__( 'Repository and branch cache updated. %1$d repositories and %2$d branches loaded from @%3$s.', 'github-repo-selector' ), count( $options ), (int) $refresh['branch_count'], esc_html( $username ) ) . '</p></div>';
			} else {
				echo '<div class="notice notice-error"><p>' . esc_html__( 'GitHub connected, but no repositories came back. Check that the fine-grained token has access to repositories.', 'github-repo-selector' ) . '</p></div>';
			}
		}
	}

	$token = get_option( 'github_repo_selector_token', '' );
	$api = new \GitHub_Repo_Selector\GitHub_API();
	$connected_username = $api->get_authenticated_username();
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'GitHub Repo Selector Settings', 'github-repo-selector' ); ?></h1>

		<?php if ( ! empty( $connected_username ) ) : ?>
			<div class="notice notice-info inline"><p>
				<?php printf( esc_html__( 'Connected GitHub account: %s', 'github-repo-selector' ), '<strong>' . esc_html( $connected_username ) . '</strong>' ); ?>
			</p></div>
		<?php elseif ( ! empty( $token ) ) : ?>
			<div class="notice notice-warning inline"><p><?php esc_html_e( 'Token saved, but the GitHub account could not be detected. Check the token permissions or create a fresh fine-grained token.', 'github-repo-selector' ); ?></p></div>
		<?php endif; ?>
		<form method="post">
			<?php wp_nonce_field( 'github_repo_selector_nonce' ); ?>
			<table class="form-table">
				<tr>
					<th scope="row">
						<label for="github_token"><?php esc_html_e( 'GitHub Personal Access Token', 'github-repo-selector' ); ?></label>
					</th>
					<td>
						<input type="password" name="github_token" id="github_token" value="<?php echo esc_attr( $token ); ?>" class="regular-text" />
						<p class="description">
							<?php
							printf(
								esc_html__( 'Create a token at %s with repo access permissions.', 'github-repo-selector' ),
								'<a href="https://github.com/settings/tokens" target="_blank">GitHub Settings</a>'
							);
							?>
						</p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>

		<hr />
		<h2><?php esc_html_e( 'Repository & Branch Dropdown Cache', 'github-repo-selector' ); ?></h2>
		<p><?php esc_html_e( 'Use this to pull repositories from the GitHub account connected to the saved token. Elementor uses this saved list for the repository dropdowns.', 'github-repo-selector' ); ?></p>
		<?php
		$cached_repos = \GitHub_Repo_Selector\Settings::get_saved_repo_options();
		$last_updated = get_option( 'github_repo_selector_repo_cache_updated', '' );
		?>
		<p id="github-repo-selector-cache-status">
			<strong><?php esc_html_e( 'Cached repositories:', 'github-repo-selector' ); ?></strong> <?php echo esc_html( count( $cached_repos ) ); ?>
			<?php $cached_branches = get_option( 'github_repo_selector_branch_options', [] ); $branch_total = 0; if ( is_array( $cached_branches ) ) { foreach ( $cached_branches as $branch_list ) { if ( is_array( $branch_list ) ) { $branch_total += count( $branch_list ); } } } ?>
			<br><strong><?php esc_html_e( 'Cached branches:', 'github-repo-selector' ); ?></strong> <?php echo esc_html( $branch_total ); ?>
			<?php if ( ! empty( $last_updated ) ) : ?>
				<br><strong><?php esc_html_e( 'Last updated:', 'github-repo-selector' ); ?></strong> <?php echo esc_html( $last_updated ); ?>
			<?php endif; ?>
		</p>
		<form method="post" id="github-repo-selector-update-cache-form">
			<?php wp_nonce_field( 'github_repo_selector_update_cache_nonce' ); ?>
			<p>
				<button type="submit" name="github_repo_selector_update_cache" value="1" id="update-github-repos-settings" class="button button-secondary">
					<?php esc_html_e( 'Update Repositories & Branches', 'github-repo-selector' ); ?>
				</button>
				<span class="description" style="display:block;margin-top:8px;">
					<?php esc_html_e( 'This refreshes repositories and branches from GitHub, then reloads the settings page with updated cache counts.', 'github-repo-selector' ); ?>
				</span>
			</p>
		</form>
		<div id="github-repo-selector-settings-cache-message" style="display:none; max-width: 760px;"></div>
	</div>
	<?php
}

/**
 * Enqueue admin styles
 */
function github_repo_selector_enqueue_admin_assets() {
	wp_enqueue_style(
		'github-repo-selector-admin',
		GITHUB_REPO_SELECTOR_PLUGIN_URL . 'assets/css/admin.css',
		[],
		GITHUB_REPO_SELECTOR_VERSION
	);

	if ( is_admin() ) {
		wp_enqueue_script(
			'github-repo-selector-editor',
			GITHUB_REPO_SELECTOR_PLUGIN_URL . 'assets/js/elementor-editor.js',
			[ 'jquery' ],
			GITHUB_REPO_SELECTOR_VERSION,
			true
		);
	}

	wp_localize_script(
		'github-repo-selector-editor',
		'githubRepoSelectorEditor',
		[
			'ajaxurl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'github_repo_selector_nonce' ),
		]
	);

	wp_add_inline_script(
		'github-repo-selector-editor',
		'window.githubRepoSelectorNonce = ' . wp_json_encode( wp_create_nonce( 'github_repo_selector_nonce' ) ) . ';',
		'before'
	);
}
add_action( 'admin_enqueue_scripts', 'github_repo_selector_enqueue_admin_assets' );

/**
 * Enqueue frontend styles
 */
function github_repo_selector_enqueue_frontend_assets() {
	wp_enqueue_style(
		'github-repo-selector-widget',
		GITHUB_REPO_SELECTOR_PLUGIN_URL . 'assets/css/widget.css',
		[],
		GITHUB_REPO_SELECTOR_VERSION
	);

	wp_enqueue_script(
		'github-repo-selector-frontend',
		GITHUB_REPO_SELECTOR_PLUGIN_URL . 'assets/js/frontend.js',
		[ 'jquery' ],
		GITHUB_REPO_SELECTOR_VERSION,
		true
	);

	wp_localize_script(
		'github-repo-selector-frontend',
		'githubRepoSelectorFrontend',
		[
			'ajaxurl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'github_repo_selector_nonce' ),
		]
	);
}
add_action( 'wp_enqueue_scripts', 'github_repo_selector_enqueue_frontend_assets' );

/**
 * Activation hook
 */
register_activation_hook( __FILE__, 'github_repo_selector_activate' );

function github_repo_selector_activate() {
	// Run any setup tasks
	flush_rewrite_rules();
}

/**
 * Deactivation hook
 */
register_deactivation_hook( __FILE__, 'github_repo_selector_deactivate' );

function github_repo_selector_deactivate() {
	flush_rewrite_rules();
}
