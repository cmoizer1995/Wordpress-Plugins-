# GitHub Repo Selector Plugin Configuration

## Recommended Settings

### For Best Performance

1. **GitHub Token Type:** Personal Access Token (not OAuth)
2. **Cache Duration:** 1 hour (automatic)
3. **Max Repositories to Display:** 5-10 per page
4. **README Max Height:** 400-600px

### Security Settings

- Enable two-factor authentication on your GitHub account
- Use a token with minimal necessary scopes
- Rotate your token every 3-6 months
- Don't share or commit tokens to version control

## Plugin Hooks & Filters

### Available Filters

**Filter repo list before displaying:**
```php
add_filter( 'github_repo_selector_repos', function( $repos, $username ) {
    // Modify or filter repos
    return $repos;
}, 10, 2 );
```

**Filter branch list:**
```php
add_filter( 'github_repo_selector_branches', function( $branches, $owner, $repo ) {
    // Modify or filter branches
    return $branches;
}, 10, 3 );
```

**Filter README content:**
```php
add_filter( 'github_repo_selector_readme', function( $readme, $owner, $repo, $branch ) {
    // Modify README display
    return $readme;
}, 10, 4 );
```

### Available Actions

**After widget renders:**
```php
add_action( 'github_repo_selector_after_widget', function() {
    // Add custom code after widget
});
```

**After repo card renders:**
```php
add_action( 'github_repo_selector_after_repo_card', function( $repo_data ) {
    // Add custom code after each repo
});
```

## Database Options

Plugin stores these WordPress options:

- `github_repo_selector_token` - GitHub Personal Access Token

Transients (temporary cache):
- `github_repos_{username}` - Cached repo list
- `github_branches_{owner}_{repo}` - Cached branch list
- `github_repo_details_{owner}_{repo}` - Cached repo details
- `github_readme_{owner}_{repo}_{branch}` - Cached README

## Troubleshooting Checklist

- [ ] GitHub username is correct
- [ ] Personal Access Token has proper scopes
- [ ] Token is still valid (not expired)
- [ ] Repository is public
- [ ] Elementor is activated
- [ ] WordPress cache is cleared
- [ ] Browser cache is cleared
- [ ] No PHP errors in debug.log

## Performance Optimization

### Recommended WordPress Settings

```php
// In wp-config.php
define( 'WP_CACHE', true );
define( 'WP_MEMORY_LIMIT', '256M' );

// Enable object caching
define( 'WP_REDIS_HOST', 'localhost' );
define( 'WP_REDIS_PORT', 6379 );
```

### Caching Plugin Settings

If using WP Super Cache, W3 Total Cache, or similar:
- Enable object caching
- Cache GitHub API responses
- Set cache expiration to 1 hour minimum

## Server Requirements

- PHP 7.4 or higher
- WordPress 5.0 or higher
- Elementor 2.0 or higher
- cURL or fsockopen for API requests
- Outbound HTTPS to api.github.com

## API Rate Limits

GitHub API limits:
- **Without token:** 60 requests/hour
- **With token:** 5000 requests/hour

Plugin reduces requests through:
- Automatic 1-hour response caching
- Selective repo fetching
- Transient-based caching

## File Permissions

Ensure these directories are writable:
- `/wp-content/plugins/github-repo-selector/`

## Debugging

Enable WordPress debug mode:

```php
// In wp-config.php
define( 'WP_DEBUG', true );
define( 'WP_DEBUG_LOG', true );
define( 'WP_DEBUG_DISPLAY', false );

// Check /wp-content/debug.log for errors
```

## Advanced Usage

### Displaying Repos from Different Users

Add multiple widgets with different usernames:
1. Widget 1: Show repos from `user1`
2. Widget 2: Show repos from `user2`
3. Each widget is independent

### Custom Styling

All styling uses CSS variables and Elementor controls. Override in your theme:

```css
.github-repo-container {
    --primary-color: #0969da;
    --stats-color: #57606a;
}
```

### API Customization

Extend the GitHub_API class:

```php
class My_GitHub_API extends \GitHub_Repo_Selector\GitHub_API {
    public function get_custom_data() {
        // Your custom API logic
    }
}
```

## Support Resources

- [GitHub API Docs](https://docs.github.com/en/rest)
- [Elementor Developer Docs](https://developers.elementor.com/)
- [WordPress Plugin Development](https://developer.wordpress.org/plugins/)

## Changelog

See `README.md` for version history and release notes.

---

**Last Updated:** 2024
**Plugin Version:** v1.0
