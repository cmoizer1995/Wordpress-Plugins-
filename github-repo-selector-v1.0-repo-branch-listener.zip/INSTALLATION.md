# Installation & Setup Guide

## Quick Start

### Step 1: Install the Plugin

1. **Via WordPress Admin Panel:**
   - Download the plugin folder
   - Go to WordPress Admin > Plugins > Add New
   - Click "Upload Plugin"
   - Select the zip file and click "Install Now"
   - Click "Activate Plugin"

2. **Via FTP:**
   - Extract the plugin folder
   - Upload to `/wp-content/plugins/`
   - Activate through WordPress Admin > Plugins

### Step 2: Configure GitHub Token

1. Go to **Settings > GitHub Repo Selector** in WordPress admin
2. Generate a Personal Access Token at [GitHub Settings > Tokens](https://github.com/settings/tokens/new)
3. Give it a name like "WordPress GitHub Widget"
4. Select scope: `public_repo` (or `repo` for private repos)
5. Generate and copy the token
6. Paste into the WordPress settings and save

### Step 3: Use in Elementor

1. Open any page/post in Elementor Editor
2. Search for "GitHub Repos" in the widget panel
3. Drag the widget onto your page
4. Enter a GitHub username
5. Click "Update Repositories"
6. Select repositories to display
7. Customize styling
8. Publish!

## Detailed Configuration

### GitHub Token Scopes

**For public repositories only:**
- Scope: `public_repo`
- Allows reading public repos only
- More secure

**For public + private repositories:**
- Scope: `repo`
- Full control of private repos
- Use only if needed

**Recommended permissions:**
```
✓ public_repo
✓ read:user
✓ user:email
```

### Widget Settings Explained

#### GitHub Settings Tab

**GitHub Username**
- The GitHub account username to display repos from
- Can be an individual user or organization
- Must have public repos

**Update Repositories Button**
- Fetches the list of repositories from GitHub
- Only refreshes when you click it
- Can be clicked multiple times

**Select Repositories**
- Multi-select dropdown to choose which repos to display
- Only appears after fetching repos
- Can select multiple repos

#### Display Options Tab

**Show README Content**
- Displays the README.md file content
- Only shows if README exists
- Converts markdown to HTML
- Max height can be set

**Show Repository Description**
- Shows the description from repo settings
- Appears under the repo name
- Limited to one line

**Show Repository Stats**
- Displays: Stars, Forks, Watchers
- Uses GitHub API counts
- Updated hourly via caching

**Show GitHub Link Button**
- Adds button linking to the repo on GitHub
- Opens in new tab
- Customizable via styling

#### Branch Settings Tab

**Show Branch Selector**
- Adds dropdown to select different branches
- Only shows fetched branches
- Updates README when branch changes

**Default Branch**
- Used when branch selector is disabled
- Should match your repo's default
- Common: "main" or "master"

### Style Customization

All styling is done in Elementor's Style tabs:

1. **Container Style**
   - Outer wrapper background and borders
   - Controls overall card styling

2. **Repository Card Style**
   - Individual repo card appearance
   - Padding, margin, borders, shadows

3. **Title Style**
   - Repository name styling
   - Font, size, color, weight

## Common Scenarios

### Display Multiple Repositories

1. Enter GitHub username
2. Click "Update Repositories"
3. Select multiple repos in the dropdown
4. Save - all selected repos will display

### Show Different Branches

1. Enable "Show Branch Selector"
2. Set "Default Branch" to your main branch (usually "main")
3. Users can select branches to view
4. README updates for selected branch

### Custom Styling

1. Go to Style tabs
2. Customize colors, fonts, spacing
3. Use Elementor's responsive controls
4. Preview on different devices

### Display Multiple Widgets

You can add multiple GitHub Repo widgets on the same page:
- Each widget can show different repos
- Each widget can have different styling
- All use the same GitHub account

## Troubleshooting

### Widget Not Showing

**Check:**
- Elementor is installed and active
- GitHub username is entered
- Repositories are selected
- Browser cache is cleared

**Fix:**
```
1. Deactivate plugin
2. Clear all caches
3. Reactivate plugin
4. Clear browser cache
5. Try again
```

### "No Repositories Found"

**Possible causes:**
- Username doesn't exist
- Username has no public repos
- GitHub API error
- Token permissions too limited

**Fix:**
1. Verify username at github.com/[username]
2. Ensure account has public repos
3. Check GitHub API status
4. Verify token scopes include public_repo

### README Not Displaying

**Check:**
- Repository has README.md file
- File is in repository root
- Branch name is correct
- Token has proper permissions

**Fix:**
1. Check GitHub manually for README
2. Verify branch in widget settings
3. Try a different repository
4. Clear plugin cache (if applicable)

### Slow Loading

**Possible causes:**
- Large README files
- Too many repos selected
- GitHub API slow
- Site performance issues

**Fix:**
1. Limit number of repos displayed
2. Disable README if not needed
3. Use smaller READMEs
4. Check site performance

### GitHub API Rate Limit

**Limits:**
- Unauthenticated: 60 requests/hour
- Authenticated: 5000 requests/hour
- Reset every hour

**Solution:**
- Plugin caches responses automatically
- Each repo is cached for 1 hour
- Clear cache to force refresh
- Use Personal Access Token

## API Caching

The plugin automatically caches:
- Repository lists (1 hour)
- Branch lists (1 hour)
- Repository details (1 hour)
- README content (1 hour)

**To clear cache:**
1. Deactivate plugin momentarily
2. Or directly in database:
   ```sql
   DELETE FROM wp_options 
   WHERE option_name LIKE '%github_repo%';
   ```

## Performance Tips

1. **Limit repositories displayed**
   - Show only necessary repos
   - Reduces API calls

2. **Disable unnecessary features**
   - Disable stats if not needed
   - Disable README for speed

3. **Use appropriate branch**
   - Load branch with smallest README
   - Avoids large content

4. **Cache optimization**
   - Use a WordPress caching plugin
   - Cache the entire page

## Security Notes

- Never share your Personal Access Token
- Store token in plugin settings only
- Token is stored in WordPress database
- Use limited scopes (public_repo)
- Regenerate token if compromised

## Support & Help

For issues or questions:
1. Check this guide first
2. Review GitHub repo documentation
3. Check Elementor documentation
4. Clear all caches and try again
5. Verify GitHub API status

## Next Steps

- Add widget to your pages
- Customize styling to match your site
- Configure repository selection
- Test on different devices
- Monitor GitHub API usage

Happy coding! 🚀
