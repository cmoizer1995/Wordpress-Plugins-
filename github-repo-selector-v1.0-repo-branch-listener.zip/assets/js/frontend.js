( function( $ ) {
	'use strict';

	function markdownFallback( text ) {
		return String( text || '' )
			.replace( /^### (.*?)$/gm, '<h3>$1</h3>' )
			.replace( /^## (.*?)$/gm, '<h2>$1</h2>' )
			.replace( /^# (.*?)$/gm, '<h1>$1</h1>' )
			.replace( /\*\*(.*?)\*\*/g, '<strong>$1</strong>' )
			.replace( /`([^`]+)`/g, '<code>$1</code>' )
			.replace( /\[(.*?)\]\((.*?)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>' )
			.replace( /\n/g, '<br>' );
	}

	function encodeBranchForGitHubUrl( branch ) {
		// GitHub branch names can contain slashes. Encoding the whole branch turns / into %2F,
		// which can make GitHub fall back or fail. Encode each path part instead.
		return String( branch || '' ).split( '/' ).map( encodeURIComponent ).join( '/' );
	}

	function getBranchUrl( baseUrl, branch ) {
		return String( baseUrl || '' ).replace( /\/$/, '' ) + '/tree/' + encodeBranchForGitHubUrl( branch );
	}

	function getBranchZipUrl( baseUrl, branch ) {
		return String( baseUrl || '' ).replace( /\/$/, '' ) + '/archive/refs/heads/' + encodeBranchForGitHubUrl( branch ) + '.zip';
	}

	function updateCardBranchLinks( select ) {
		const $card = $( select ).closest( '.repo-card' );
		const branch = select.value || select.dataset.currentBranch || '';
		const baseUrl = select.dataset.baseUrl || '';
		const branchUrl = getBranchUrl( baseUrl, branch );
		const zipUrl = getBranchZipUrl( baseUrl, branch );

		select.dataset.currentBranch = branch;
		$card.attr( 'data-selected-branch', branch );
		$card.find( '.repo-title-link, .repo-view-button' ).attr( 'href', branchUrl ).attr( 'data-selected-branch', branch );
		$card.find( '.repo-download-button' ).attr( 'href', zipUrl ).attr( 'data-selected-branch', branch );

		return branchUrl;
	}

	$( document ).on( 'change', '.github-repo-container .branch-selector', function() {
		const select = this;
		const $card = $( select ).closest( '.repo-card' );
		const owner = select.dataset.owner || '';
		const repo = select.dataset.repo || '';
		const branch = select.value || select.dataset.currentBranch || '';
		const branchUrl = updateCardBranchLinks( select );

		const $readme = $card.find( '.repo-readme-container' );
		if ( ! $readme.length || ! owner || ! repo || ! branch ) {
			return;
		}

		$readme.addClass( 'is-loading' ).html( '<p class="repo-loading-readme">Loading README for ' + branch + '...</p>' );

		$.ajax( {
			url: ( window.githubRepoSelectorFrontend && window.githubRepoSelectorFrontend.ajaxurl ) || '/wp-admin/admin-ajax.php',
			method: 'POST',
			data: {
				action: 'fetch_github_repo_readme',
				nonce: ( window.githubRepoSelectorFrontend && window.githubRepoSelectorFrontend.nonce ) || '',
				owner: owner,
				repo: repo,
				branch: branch
			}
		} ).done( function( response ) {
			if ( response && response.success && response.data && response.data.readme ) {
				$readme.html( response.data.readme );
			} else {
				$readme.html( '<p class="repo-no-readme">No README available for this branch.</p>' );
			}
		} ).fail( function() {
			$readme.html( '<p class="repo-no-readme">Could not load README for this branch.</p>' );
		} ).always( function() {
			$readme.removeClass( 'is-loading' );
		} );
	} );

	$( document ).on( 'click', '.github-repo-container .repo-title-link, .github-repo-container .repo-view-button, .github-repo-container .repo-download-button', function() {
		const $card = $( this ).closest( '.repo-card' );
		const select = $card.find( '.branch-selector' ).get( 0 );
		if ( select ) {
			updateCardBranchLinks( select );
		}
	} );

	$( function() {
		$( '.github-repo-container .branch-selector' ).each( function() {
			updateCardBranchLinks( this );
		} );
	} );
} )( jQuery );
