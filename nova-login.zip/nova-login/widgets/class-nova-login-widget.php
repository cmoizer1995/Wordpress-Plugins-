<?php
if (!defined('ABSPATH')) {
    exit;
}

class Nova_Login_Elementor_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'nova_login_settings';
    }

    public function get_title() {
        return 'Nova Login Settings';
    }

    public function get_icon() {
        return 'eicon-settings';
    }

    public function get_categories() {
        return ['general'];
    }

    public function get_script_depends() {
        return ['nova-login-widget'];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => 'Settings',
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'widget_description',
            [
                'type' => \Elementor\Controls_Manager::RAW_HTML,
                'raw' => 'This widget displays the Nova Login settings form for administrators to customize colors and footer text.',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'style_section',
            [
                'label' => 'Style',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'form_background',
            [
                'label' => 'Form Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .nova-login-widget-form' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'form_padding',
            [
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .nova-login-widget-form' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'form_border_radius',
            [
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .nova-login-widget-form' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        if (!current_user_can('manage_options')) {
            echo '<p>You do not have permission to access this page.</p>';
            return;
        }
        
        $color_1 = get_option('nova_login_color_1', '#667eea');
        $color_2 = get_option('nova_login_color_2', '#764ba2');
        $footer_text = get_option('nova_login_footer_text', '© ' . date('Y') . ' All rights reserved.');
        
        ?>
        <div class="nova-login-widget-form">
            <h3>Nova Login Settings</h3>
            
            <form id="nova-login-settings-form">
                <div class="form-group">
                    <label for="nova_color_1">Primary Gradient Color</label>
                    <div style="display: flex; gap: 10px;">
                        <input 
                            type="color" 
                            id="nova_color_1" 
                            value="<?php echo esc_attr($color_1); ?>"
                            style="width: 80px; height: 50px; border: none; border-radius: 4px; cursor: pointer;"
                        >
                        <input 
                            type="text" 
                            id="nova_color_1_hex" 
                            value="<?php echo esc_attr($color_1); ?>"
                            style="flex: 1; padding: 8px; border: 1px solid #ddd; border-radius: 4px;"
                            readonly
                        >
                    </div>
                </div>

                <div class="form-group" style="margin-top: 15px;">
                    <label for="nova_color_2">Secondary Gradient Color</label>
                    <div style="display: flex; gap: 10px;">
                        <input 
                            type="color" 
                            id="nova_color_2" 
                            value="<?php echo esc_attr($color_2); ?>"
                            style="width: 80px; height: 50px; border: none; border-radius: 4px; cursor: pointer;"
                        >
                        <input 
                            type="text" 
                            id="nova_color_2_hex" 
                            value="<?php echo esc_attr($color_2); ?>"
                            style="flex: 1; padding: 8px; border: 1px solid #ddd; border-radius: 4px;"
                            readonly
                        >
                    </div>
                </div>

                <div class="form-group" style="margin-top: 15px;">
                    <label for="nova_footer_text">Footer Copyright Text</label>
                    <textarea 
                        id="nova_footer_text" 
                        style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; font-family: monospace; min-height: 80px;"
                    ><?php echo esc_textarea($footer_text); ?></textarea>
                </div>

                <button 
                    type="submit" 
                    style="margin-top: 15px; padding: 10px 20px; background: linear-gradient(135deg, <?php echo esc_attr($color_1); ?> 0%, <?php echo esc_attr($color_2); ?> 100%); color: white; border: none; border-radius: 4px; cursor: pointer; font-weight: bold;"
                >
                    Save Settings
                </button>
            </form>

            <div id="nova-login-message" style="margin-top: 15px; padding: 10px; display: none; border-radius: 4px;"></div>

            <!-- Color Preview -->
            <div style="margin-top: 30px; padding: 20px; background: #f9f9f9; border-radius: 8px;">
                <h4>Preview</h4>
                <div style="
                    height: 150px;
                    background: linear-gradient(135deg, <?php echo esc_attr($color_1); ?> 0%, <?php echo esc_attr($color_2); ?> 100%);
                    border-radius: 8px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    color: white;
                    font-size: 18px;
                    font-weight: bold;
                    text-shadow: 0 2px 10px rgba(0,0,0,0.2);
                " id="nova-preview">
                    Your Login Page
                </div>
            </div>
        </div>

        <style>
            .nova-login-widget-form {
                padding: 20px;
                background: white;
                border-radius: 8px;
            }
            .nova-login-widget-form h3 {
                margin-top: 0;
                color: #333;
            }
            .form-group {
                margin-bottom: 15px;
            }
            .form-group label {
                display: block;
                margin-bottom: 8px;
                font-weight: bold;
                color: #333;
            }
        </style>

        <script>
        document.addEventListener('DOMContentLoaded', function() {
            const color1Input = document.getElementById('nova_color_1');
            const color1Hex = document.getElementById('nova_color_1_hex');
            const color2Input = document.getElementById('nova_color_2');
            const color2Hex = document.getElementById('nova_color_2_hex');
            const footerInput = document.getElementById('nova_footer_text');
            const form = document.getElementById('nova-login-settings-form');
            const message = document.getElementById('nova-login-message');
            const preview = document.getElementById('nova-preview');

            // Update hex value when color picker changes
            color1Input.addEventListener('change', function() {
                color1Hex.value = this.value;
                updatePreview();
            });

            color2Input.addEventListener('change', function() {
                color2Hex.value = this.value;
                updatePreview();
            });

            // Update preview in real-time
            function updatePreview() {
                const c1 = color1Input.value;
                const c2 = color2Input.value;
                preview.style.background = `linear-gradient(135deg, ${c1} 0%, ${c2} 100%)`;
            }

            // Handle form submission
            form.addEventListener('submit', function(e) {
                e.preventDefault();

                const data = {
                    action: 'save_nova_login_settings',
                    nonce: '<?php echo wp_create_nonce('nova_login_nonce'); ?>',
                    color_1: color1Input.value,
                    color_2: color2Input.value,
                    footer_text: footerInput.value
                };

                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: new URLSearchParams(data)
                })
                .then(response => response.json())
                .then(result => {
                    message.style.display = 'block';
                    if (result.success) {
                        message.style.background = '#d4edda';
                        message.style.color = '#155724';
                        message.style.border = '1px solid #c3e6cb';
                        message.textContent = '✓ Settings saved successfully!';
                    } else {
                        message.style.background = '#f8d7da';
                        message.style.color = '#721c24';
                        message.style.border = '1px solid #f5c6cb';
                        message.textContent = '✗ Error saving settings';
                    }
                    setTimeout(() => {
                        message.style.display = 'none';
                    }, 3000);
                });
            });
        });
        </script>
        <?php
    }
}
