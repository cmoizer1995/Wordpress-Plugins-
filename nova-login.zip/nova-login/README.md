# Nova Login

A standalone WordPress plugin that replaces the default login page with a gorgeous, modern design featuring beautiful gradients and smooth animations.

## Features

✅ **Gorgeous Purple Gradient Background** - Beautiful 135° gradient from #667eea to #764ba2
✅ **Animated Floating Shapes** - Floating background elements with smooth animations
✅ **Smooth Animations** - Slide-up entrance animations for all form elements
✅ **Responsive Design** - Looks perfect on desktop, tablet, and mobile
✅ **Professional Typography** - Using Google Fonts (Outfit + Crimson Text)
✅ **Custom Styling** - Form fields, buttons, and links all beautifully styled
✅ **Easy to Use** - Works with standard WordPress login form
✅ **Fully Customizable** - Change colors to match your brand

## Installation

1. Download the plugin
2. Extract to `/wp-content/plugins/nova-login/`
3. Activate the plugin in WordPress admin
4. Go to login page - it's automatically beautiful!

## How It Works

Simply activate the plugin and your WordPress login page will be transformed with:

- Beautiful gradient background
- Animated floating shapes
- Smooth transitions and animations
- Custom styled form fields
- Professional typography

## Customization

Go to **Nova Login** in admin settings to:
- Change gradient colors
- Add custom footer text
- Preview changes in real-time

## Compatible With

- All WordPress versions
- Works with any WordPress theme
- Compatible with other security plugins

## Version

1.0.0

## Author

Connor Moizer
https://ConnorMoizer.com

## License

GPL v2 or later
