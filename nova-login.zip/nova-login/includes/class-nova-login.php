<?php
class Nova_Login {
    
    public function __construct() {
        add_action('login_enqueue_scripts', array($this, 'enqueue_styles'));
        add_filter('login_headerurl', array($this, 'custom_login_url'));
        add_filter('login_headertitle', array($this, 'custom_login_title'));
        add_action('admin_menu', array($this, 'register_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('wp_loaded', array($this, 'handle_logout_url'));
        
        // Override WordPress default logout
        add_action('check_admin_referer', array($this, 'override_wordpress_logout'), 1, 2);
        add_action('wp_logout', array($this, 'handle_logout_redirect'));
    }

    public static function activate() {
        if (!get_option('nova_login_color_1')) {
            update_option('nova_login_color_1', '#667eea');
        }
        if (!get_option('nova_login_color_2')) {
            update_option('nova_login_color_2', '#764ba2');
        }
        if (!get_option('nova_login_footer_text')) {
            update_option('nova_login_footer_text', '© ' . date('Y') . ' All rights reserved.');
        }
    }

    public static function deactivate() {
    }

    public function register_menu() {
        add_menu_page(
            'Nova Login',
            'Nova Login',
            'manage_options',
            'nova-login',
            array($this, 'render_settings'),
            'dashicons-admin-customizer',
            90
        );
    }

    public function register_settings() {
        register_setting('nova_login_group', 'nova_login_color_1', array(
            'sanitize_callback' => 'sanitize_hex_color'
        ));
        register_setting('nova_login_group', 'nova_login_color_2', array(
            'sanitize_callback' => 'sanitize_hex_color'
        ));
        register_setting('nova_login_group', 'nova_login_footer_text', array(
            'sanitize_callback' => 'wp_kses_post'
        ));
    }

    public function render_settings() {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        include NOVA_LOGIN_PATH . 'templates/settings.php';
    }

    public function handle_logout_url() {
        if (isset($_GET['logout_nova'])) {
            if (!isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'nova-logout')) {
                wp_logout();
            } else {
                wp_logout();
            }
            wp_redirect(wp_login_url());
            exit;
        }
    }

    public function override_wordpress_logout($action, $result) {
        if ($action === 'log-out') {
            wp_logout();
            wp_redirect(wp_login_url());
            exit;
        }
    }

    public function handle_logout_redirect() {
        wp_redirect(wp_login_url());
        exit;
    }

    public function get_logout_url() {
        return wp_nonce_url(home_url('?logout_nova=1'), 'nova-logout', '_wpnonce');
    }

    public function enqueue_styles() {
        wp_enqueue_style('nova-login-base', NOVA_LOGIN_URL . 'assets/css/login.css', array(), NOVA_LOGIN_VERSION);
        
        $color_1 = get_option('nova_login_color_1', '#667eea');
        $color_2 = get_option('nova_login_color_2', '#764ba2');
        
        $custom_css = "
        body.login {
            background: linear-gradient(135deg, {$color_1} 0%, {$color_2} 100%) !important;
        }
        
        .login h1 a {
            background: linear-gradient(135deg, {$color_1} 0%, {$color_2} 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .login input[type=\"text\"]:focus,
        .login input[type=\"password\"]:focus,
        .login input[type=\"email\"]:focus {
            border-color: {$color_1};
            box-shadow: 0 0 0 4px " . $this->hex_to_rgba($color_1, 0.1) . ";
        }
        
        .login .button,
        .login input[type=\"submit\"] {
            background: linear-gradient(135deg, {$color_1} 0%, {$color_2} 100%);
            box-shadow: 0 4px 15px " . $this->hex_to_rgba($color_1, 0.3) . ";
        }
        
        .login .button:hover,
        .login input[type=\"submit\"]:hover {
            box-shadow: 0 8px 25px " . $this->hex_to_rgba($color_1, 0.4) . ";
        }
        
        .login a {
            color: {$color_1};
        }
        
        .login a:hover {
            color: {$color_2};
        }
        
        .login .forgetmenot input[type=\"checkbox\"] {
            accent-color: {$color_1};
        }
        
        .login .message,
        .login .notice {
            background: linear-gradient(135deg, " . $this->hex_to_rgba($color_1, 0.05) . " 0%, " . $this->hex_to_rgba($color_2, 0.05) . " 100%);
            border-left-color: {$color_1};
        }
        ";
        
        wp_add_inline_style('nova-login-base', $custom_css);
    }

    private function hex_to_rgba($hex, $alpha = 1) {
        $hex = str_replace('#', '', $hex);
        if (strlen($hex) == 3) {
            $hex = str_repeat(substr($hex, 0, 1), 2) . str_repeat(substr($hex, 1, 1), 2) . str_repeat(substr($hex, 2, 1), 2);
        }
        $rgb = array(hexdec(substr($hex, 0, 2)), hexdec(substr($hex, 2, 2)), hexdec(substr($hex, 4, 2)));
        return 'rgba(' . implode(',', $rgb) . ',' . $alpha . ')';
    }

    public function custom_login_url() {
        return home_url();
    }

    public function custom_login_title() {
        return get_bloginfo('name');
    }
}
