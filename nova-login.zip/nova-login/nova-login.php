<?php
/**
 * Plugin Name: Nova Login
 * Description: Custom beautiful login page with gorgeous gradient design - fully customizable
 * Version: 1.0.0
 * Author: Connor Moizer
 * Author URI: https://ConnorMoizer.com
 * Text Domain: nova-login
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit;
}

define('NOVA_LOGIN_VERSION', '1.0.0');
define('NOVA_LOGIN_PATH', plugin_dir_path(__FILE__));
define('NOVA_LOGIN_URL', plugin_dir_url(__FILE__));

// Load the main class
require_once NOVA_LOGIN_PATH . 'includes/class-nova-login.php';

// Activation/Deactivation hooks
register_activation_hook(__FILE__, array('Nova_Login', 'activate'));
register_deactivation_hook(__FILE__, array('Nova_Login', 'deactivate'));

// Handle reset action
add_action('admin_init', function() {
    if (isset($_POST['action']) && $_POST['action'] === 'reset_nova_login') {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'reset_nova_login_nonce')) {
            return;
        }
        
        update_option('nova_login_color_1', '#667eea');
        update_option('nova_login_color_2', '#764ba2');
        update_option('nova_login_footer_text', '© ' . date('Y') . ' All rights reserved.');
        
        wp_redirect(admin_url('admin.php?page=nova-login&reset=success'));
        exit;
    }
    
    if (isset($_GET['reset']) && $_GET['reset'] === 'success') {
        add_action('admin_notices', function() {
            echo '<div class="notice notice-success is-dismissible"><p>Nova Login settings have been reset to defaults!</p></div>';
        });
    }
});

// Load Elementor widget
add_action('elementor/widgets/register', function( $widgets_manager ) {
    require_once NOVA_LOGIN_PATH . 'widgets/class-nova-login-widget.php';
    $widgets_manager->register(new \Nova_Login_Elementor_Widget());
});

// AJAX handler for saving settings
add_action('wp_ajax_save_nova_login_settings', function() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized', 403);
    }

    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'nova_login_nonce')) {
        wp_send_json_error('Nonce verification failed', 403);
    }

    $color_1 = isset($_POST['color_1']) ? sanitize_hex_color($_POST['color_1']) : '#667eea';
    $color_2 = isset($_POST['color_2']) ? sanitize_hex_color($_POST['color_2']) : '#764ba2';
    $footer_text = isset($_POST['footer_text']) ? wp_kses_post($_POST['footer_text']) : '';

    update_option('nova_login_color_1', $color_1);
    update_option('nova_login_color_2', $color_2);
    update_option('nova_login_footer_text', $footer_text);

    wp_send_json_success(array(
        'message' => 'Settings saved successfully!',
        'color_1' => $color_1,
        'color_2' => $color_2,
        'footer_text' => $footer_text
    ));
});

// Initialize the plugin
new Nova_Login();
