<?php
if (!current_user_can('manage_options')) {
    wp_die('Unauthorized');
}
?>

<div class="wrap">
    <h1>Nova Login Settings</h1>
    
    <div style="max-width: 800px; margin: 20px 0;">
        <form method="post" action="options.php">
            <?php settings_fields('nova_login_group'); ?>
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="nova_login_color_1">Gradient Color 1 (Primary)</label>
                    </th>
                    <td>
                        <input 
                            type="color" 
                            id="nova_login_color_1" 
                            name="nova_login_color_1" 
                            value="<?php echo esc_attr(get_option('nova_login_color_1', '#667eea')); ?>"
                            style="width: 100px; height: 50px; border: none; border-radius: 4px; cursor: pointer;"
                        >
                        <input 
                            type="text" 
                            id="nova_login_color_1_hex" 
                            value="<?php echo esc_attr(get_option('nova_login_color_1', '#667eea')); ?>"
                            style="width: 120px; margin-left: 15px; padding: 8px; border: 1px solid #ddd; border-radius: 4px;"
                            readonly
                        >
                        <p class="description">The main gradient color (top-left corner)</p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="nova_login_color_2">Gradient Color 2 (Secondary)</label>
                    </th>
                    <td>
                        <input 
                            type="color" 
                            id="nova_login_color_2" 
                            name="nova_login_color_2" 
                            value="<?php echo esc_attr(get_option('nova_login_color_2', '#764ba2')); ?>"
                            style="width: 100px; height: 50px; border: none; border-radius: 4px; cursor: pointer;"
                        >
                        <input 
                            type="text" 
                            id="nova_login_color_2_hex" 
                            value="<?php echo esc_attr(get_option('nova_login_color_2', '#764ba2')); ?>"
                            style="width: 120px; margin-left: 15px; padding: 8px; border: 1px solid #ddd; border-radius: 4px;"
                            readonly
                        >
                        <p class="description">The secondary gradient color (bottom-right corner)</p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="nova_login_footer_text">Footer Text</label>
                    </th>
                    <td>
                        <textarea 
                            id="nova_login_footer_text" 
                            name="nova_login_footer_text"
                            rows="3"
                            style="width: 100%; max-width: 500px; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-family: monospace;"
                        ><?php echo esc_textarea(get_option('nova_login_footer_text', '© ' . date('Y') . ' All rights reserved.')); ?></textarea>
                        <p class="description">Text that appears at the bottom of the login page</p>
                    </td>
                </tr>
            </table>
            
            <?php submit_button(); ?>
        </form>
    </div>
    
    <!-- Color Preview -->
    <div style="max-width: 800px; margin-top: 40px; padding: 20px; background: #f9f9f9; border-radius: 8px;">
        <h2>Preview</h2>
        <p style="margin-bottom: 20px;">Here's how your login page will look with these colors:</p>
        
        <div style="
            max-width: 400px;
            height: 300px;
            background: linear-gradient(135deg, <?php echo esc_attr(get_option('nova_login_color_1', '#667eea')); ?> 0%, <?php echo esc_attr(get_option('nova_login_color_2', '#764ba2')); ?> 100%);
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
            font-weight: bold;
            text-shadow: 0 2px 10px rgba(0,0,0,0.2);
        ">
            Your Login Page
        </div>
    </div>
    
    <!-- Reset to Defaults -->
    <div style="max-width: 800px; margin-top: 40px; padding: 20px; background: #fff8e5; border-left: 4px solid #ffb81c; border-radius: 4px;">
        <h3>Reset to Defaults</h3>
        <p>To reset colors to the original beautiful purple gradient:</p>
        <form method="post" style="display: inline;">
            <input type="hidden" name="action" value="reset_nova_login">
            <?php wp_nonce_field('reset_nova_login_nonce'); ?>
            <button type="submit" class="button button-secondary" onclick="return confirm('Are you sure you want to reset to default colors?');">Reset to Defaults</button>
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Update hex value when color picker changes
    const colorInput1 = document.getElementById('nova_login_color_1');
    const hexInput1 = document.getElementById('nova_login_color_1_hex');
    
    if (colorInput1 && hexInput1) {
        colorInput1.addEventListener('change', function() {
            hexInput1.value = this.value;
        });
    }
    
    const colorInput2 = document.getElementById('nova_login_color_2');
    const hexInput2 = document.getElementById('nova_login_color_2_hex');
    
    if (colorInput2 && hexInput2) {
        colorInput2.addEventListener('change', function() {
            hexInput2.value = this.value;
        });
    }
    
    // Update preview in real-time
    const previewDiv = document.querySelector('[style*="linear-gradient"]');
    if (colorInput1 && colorInput2 && previewDiv) {
        function updatePreview() {
            const color1 = colorInput1.value;
            const color2 = colorInput2.value;
            previewDiv.style.background = `linear-gradient(135deg, ${color1} 0%, ${color2} 100%)`;
        }
        
        colorInput1.addEventListener('input', updatePreview);
        colorInput2.addEventListener('input', updatePreview);
    }
});
</script>

<style>
.form-table th {
    width: 200px;
}

.form-table input[type="color"] {
    cursor: pointer;
}

.description {
    font-size: 12px;
    color: #666;
    margin-top: 8px;
    display: block;
}
</style>
