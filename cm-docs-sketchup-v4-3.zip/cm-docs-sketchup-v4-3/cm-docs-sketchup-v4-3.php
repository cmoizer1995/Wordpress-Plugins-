<?php
/*
Plugin Name: CM Docs SketchUp v4.3
Description: Force new tab + improved Sketchfab fullscreen permissions
Version: 4.3
Author: ConnorMoizer.com
*/

if (!defined('ABSPATH')) exit;

add_action('init', function () {
    register_post_type('cm_sketchup', [
        'label' => 'SketchUp',
        'public' => true,
        'menu_icon' => 'dashicons-building',
        'supports' => ['title','thumbnail'],
        'rewrite' => ['slug' => 'sketchup','with_front'=>false],
        'has_archive' => 'sketchup'
    ]);
});

add_action('add_meta_boxes', function () {
    add_meta_box('cm_sketchup_fields', 'Project Documentation', function ($post) {

        $version = get_post_meta($post->ID,'_version',true);
        $status = get_post_meta($post->ID,'_status',true);
        $download = get_post_meta($post->ID,'_download',true);
        $view = get_post_meta($post->ID,'_view',true);
        $sketchfab = get_post_meta($post->ID,'_sketchfab',true);
        $description = get_post_meta($post->ID,'_description',true);
        ?>

        <p><strong>Version (optional)</strong><br>
        <input type="text" name="version" value="<?php echo esc_attr($version); ?>"></p>

        <p><strong>Status</strong><br>
        <select name="status">
            <option value="Concept" <?php selected($status,'Concept'); ?>>Concept</option>
            <option value="In Progress" <?php selected($status,'In Progress'); ?>>In Progress</option>
            <option value="Complete" <?php selected($status,'Complete'); ?>>Complete</option>
            <option value="Final" <?php selected($status,'Final'); ?>>Final</option>
        </select></p>

        <p><strong>Description</strong></p>
        <?php
        wp_editor(
            $description,
            'cm_sketchup_desc',
            [
                'textarea_name' => 'description',
                'media_buttons' => false,
                'textarea_rows' => 6
            ]
        );
        ?>

        <p><strong>View Model URL</strong><br>
        <input type="text" name="view" value="<?php echo esc_attr($view); ?>"></p>

        <p><strong>Download URL</strong><br>
        <input type="text" name="download" value="<?php echo esc_attr($download); ?>"></p>

        <p><strong>Sketchfab Embed</strong><br>
        <textarea name="sketchfab" style="width:100%;height:100px;"><?php echo esc_textarea($sketchfab); ?></textarea></p>

        <?php
    });
});

add_action('save_post', function ($id){
    if(isset($_POST['version'])) update_post_meta($id,'_version',sanitize_text_field($_POST['version']));
    if(isset($_POST['status'])) update_post_meta($id,'_status',sanitize_text_field($_POST['status']));
    if(isset($_POST['view'])) update_post_meta($id,'_view',esc_url($_POST['view']));
    if(isset($_POST['download'])) update_post_meta($id,'_download',esc_url($_POST['download']));
    if(isset($_POST['sketchfab'])) update_post_meta($id,'_sketchfab',$_POST['sketchfab']);
    if(isset($_POST['description'])) update_post_meta($id,'_description',$_POST['description']);
});

add_action('elementor/widgets/register', function($widgets_manager){

    class CM_Sketchup_Widget_v43 extends \Elementor\Widget_Base {

        public function get_name(){ return 'cm_sketchup_v43'; }
        public function get_title(){ return 'CM SketchUp'; }
        public function get_icon(){ return 'eicon-gallery-grid'; }
        public function get_categories(){ return ['general']; }

        protected function render(){

            global $post;

            $version = get_post_meta($post->ID,'_version',true);
            $status = get_post_meta($post->ID,'_status',true);
            $view = get_post_meta($post->ID,'_view',true);
            $download = get_post_meta($post->ID,'_download',true);
            $sketchfab = get_post_meta($post->ID,'_sketchfab',true);
            $description = get_post_meta($post->ID,'_description',true);

            echo '<div class="cm-sketchup">';

            echo '<div class="meta">';
            if(!empty($version)){
                echo '<strong>Version:</strong> '.esc_html($version).'<br>';
            }
            echo '<strong>Status:</strong> '.esc_html($status);
            echo '</div>';

            if($description){
                echo '<div class="desc">'.$description.'</div>';
            }

            if($sketchfab){
                $embed = str_replace(
                    '<iframe',
                    '<iframe allow="autoplay; fullscreen; xr-spatial-tracking" allowfullscreen webkitallowfullscreen mozallowfullscreen',
                    $sketchfab
                );
                echo '<div class="viewer">'.$embed.'</div>';
            }

            echo '<div class="buttons">';

            if($view){
                echo '<a class="cm-link" href="'.esc_url($view).'" target="_blank" rel="noopener noreferrer">👁 View Model</a>';
            }

            if($download){
                echo '<a class="cm-link" href="'.esc_url($download).'" target="_blank" rel="noopener noreferrer">📥 Download Model</a>';
            }

            echo '</div>';

            echo '</div>';
            ?>

            <style>
            .cm-sketchup .buttons{
                display:flex;
                flex-wrap:wrap;
                gap:10px;
                margin-top:15px;
            }
            .cm-sketchup .buttons a{
                flex:1;
                text-align:center;
                padding:10px 14px;
                background:#1d70b8;
                color:#fff;
                border-radius:6px;
                text-decoration:none;
            }
            @media (min-width:768px){
                .cm-sketchup .buttons a{flex:unset;width:auto;}
            }
            @media (max-width:767px){
                .cm-sketchup .buttons{flex-direction:column;}
                .cm-sketchup .buttons a{width:100%;}
            }
            .viewer iframe{
                width:100%;
                height:420px;
                border:0;
                margin-top:20px;
                border-radius:8px;
            }
            </style>

            <script>
            document.querySelectorAll('.cm-link').forEach(link=>{
                link.addEventListener('click',function(e){
                    window.open(this.href,'_blank');
                    e.preventDefault();
                });
            });
            </script>

            <?php
        }
    }

    $widgets_manager->register(new CM_Sketchup_Widget_v43());
});
