<?php
if (!defined('ABSPATH')) exit;

class ITV_Scroll_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'itv_scroll';
    }

    public function get_title() {
        return 'ITV Scroll List';
    }

    public function get_icon() {
        return 'eicon-menu-bar';
    }

    public function get_categories() {
        return ['general'];
    }

    protected function register_controls() {

        $this->start_controls_section('content', [
            'label' => 'Content'
        ]);

        $this->add_control(
            'source_type',
            [
                'label' => 'Source',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'custom',
                'options' => [
                    'custom' => 'Custom Links',
                    'menu'   => 'WordPress Menu',
                ],
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'item_text',
            [
                'label' => 'Text',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Menu Item',
            ]
        );

        $repeater->add_control(
            'item_link',
            [
                'label' => 'Link',
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => 'https://example.com',
                'show_external' => true,
                'default' => [
                    'url' => '#',
                ],
            ]
        );

        $this->add_control(
            'items',
            [
                'label' => 'Custom Links',
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'item_text' => 'NEWS',
                        'item_link' => ['url' => '#'],
                    ],
                    [
                        'item_text' => 'GALLERY',
                        'item_link' => ['url' => '#'],
                    ],
                ],
                'condition' => [
                    'source_type' => 'custom',
                ],
            ]
        );

        $menus = wp_get_nav_menus();
        $menu_options = [];

        if (!empty($menus)) {
            foreach ($menus as $menu) {
                $menu_options[$menu->term_id] = $menu->name;
            }
        }

        $this->add_control(
            'wp_menu',
            [
                'label' => 'WordPress Menu',
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => $menu_options,
                'condition' => [
                    'source_type' => 'menu',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section('style_text', [
            'label' => 'Text',
            'tab' => \Elementor\Controls_Manager::TAB_STYLE
        ]);

        $this->add_control(
            'text_color',
            [
                'label' => 'Text Colour',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .itv-scroll-list' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .itv-scroll-list a' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .itv-scroll-list a:hover' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .itv-scroll-list a:visited' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .itv-scroll-list a:active' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .itv-scroll-list a:focus' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'text_size',
            [
                'label' => 'Text Size',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 8,
                        'max' => 80,
                        'step' => 1,
                    ],
                    'em' => [
                        'min' => 0.5,
                        'max' => 5,
                        'step' => 0.1,
                    ],
                    'rem' => [
                        'min' => 0.5,
                        'max' => 5,
                        'step' => 0.1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 16,
                ],
                'selectors' => [
                    '{{WRAPPER}} .itv-scroll-list' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .itv-scroll-list a' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {

        $settings = $this->get_settings_for_display();

        echo '<div class="itv-scroll-list">';

        if ($settings['source_type'] === 'menu' && !empty($settings['wp_menu'])) {

            $menu_items = wp_get_nav_menu_items($settings['wp_menu']);

            if (!empty($menu_items)) {
                foreach ($menu_items as $item) {
                    echo '<a href="' . esc_url($item->url) . '">';
                    echo esc_html($item->title);
                    echo '</a>';
                }
            }

        } else {

            if (!empty($settings['items'])) {
                foreach ($settings['items'] as $item) {

                    $url = !empty($item['item_link']['url']) ? $item['item_link']['url'] : '#';
                    $target = !empty($item['item_link']['is_external']) ? ' target="_blank"' : '';
                    $nofollow = !empty($item['item_link']['nofollow']) ? ' rel="nofollow"' : '';

                    echo '<a href="' . esc_url($url) . '"' . $target . $nofollow . '>';
                    echo esc_html($item['item_text']);
                    echo '</a>';
                }
            }
        }

        echo '</div>';
    }
}
