<?php
/**
 * Plugin Name: ITV Scroll List v5
 * Description: Scroll list with Elementor-style Normal/Hover text controls (no transition setting needed)
 * Version: 5.0
 * Author: Connor Moizer
 */

if (!defined('ABSPATH')) exit;

add_action('elementor/widgets/register', function($widgets_manager) {
    require_once(__DIR__ . '/widget.php');
    $widgets_manager->register(new \ITV_Scroll_Widget());
});
